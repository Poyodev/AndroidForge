package example.sysinfo.app

/** Splits a kernel string into pieces and explains each one. Offline, tiny, no reflection. */
object KernelDecoder {
    class Part(val piece: String, val meaning: String)

    private val FLAGS = listOf(
        "SMP" to "Symmetric multiprocessing: the kernel can use several CPU cores.",
        "PREEMPT_RT" to "Real-time preemption: lowest latency, rare on phones.",
        "PREEMPT_DYNAMIC" to "Preemption mode can be chosen at boot.",
        "PREEMPT" to "Preemptible kernel: tasks can be interrupted sooner, which keeps the UI responsive."
    )

    fun decode(full: String): List<Part> {
        if (full.isBlank()) return listOf(Part("unavailable", "Could not read the kernel string."))
        val out = ArrayList<Part>()

        val rel = Regex("""Linux version (\S+)""").find(full)?.groupValues?.get(1)
            ?: full.trim().split(' ').first()
        out += Part(rel, "Kernel release: the Linux version first, then tags added by the vendor or Google.")
        out += decodeRelease(rel)

        Regex("""\(([^()\s]+@[^()\s]+)\)""").find(full)?.let {
            out += Part(it.groupValues[1], "Who built it: user@computer that compiled this kernel.")
        }
        Regex("""(clang|gcc) version [\d.]+""").find(full)?.let {
            val name = if (it.groupValues[1] == "clang") "Clang (LLVM)" else "GCC"
            out += Part(it.value, "The $name compiler that built the kernel.")
        }
        Regex("""LLD [\d.]+|GNU ld[^,)]*""").find(full)?.let {
            out += Part(it.value, "The linker that joined the compiled pieces into one kernel image.")
        }
        Regex("""#(\d+)""").find(full)?.let {
            out += Part(it.value, "Build counter: how many times this source tree was built.")
        }
        for ((flag, text) in FLAGS) {
            if (Regex("""\b$flag\b""").containsMatchIn(full)) out += Part(flag, text)
        }
        Regex("""[A-Z][a-z]{2} [A-Z][a-z]{2} +\d+ [\d:]{8} \S+ \d{4}""").find(full)?.let {
            out += Part(it.value, "When the kernel was compiled.")
        }
        return out
    }

    private fun decodeRelease(rel: String): List<Part> {
        val out = ArrayList<Part>()
        val m = Regex("""^(\d+)\.(\d+)(?:\.(\d+))?""").find(rel) ?: return out
        val (maj, min, patch) = m.destructured
        out += Part("$maj.$min", "Linux branch $maj.$min (major.minor). A phone usually stays on one branch for life.")
        if (patch.isNotEmpty()) {
            out += Part(patch, "Stable patch level. Higher means more upstream bug and security fixes were merged.")
        }
        for (raw in rel.substring(m.value.length).split('-')) {
            if (raw.isEmpty()) continue
            val t = raw.trimEnd('+')
            if (t.isNotEmpty()) out += Part(t, tagMeaning(t))
            if (raw.endsWith("+")) out += Part("+", "Built from a source tree with uncommitted changes.")
        }
        return out
    }

    private fun tagMeaning(t: String): String = when {
        Regex("""g[0-9a-f]{7,}""").matches(t) -> "Git commit hash the source was built from."
        t == "perf" -> "Qualcomm performance build: debug options turned off."
        t == "qgki" -> "Qualcomm's variant of Google's Generic Kernel Image."
        t == "gki" -> "Generic Kernel Image: Google's common kernel, vendor code lives in modules."
        Regex("""android\d+""").matches(t) -> "GKI branch for Android ${t.removePrefix("android")}."
        Regex("""\d+""").matches(t) -> "Number tied to the previous tag: a KMI generation or patch revision."
        Regex("""ab\d+""").matches(t) -> "Google CI build ID of this kernel."
        t == "lts" -> "Long-term support branch."
        t == "dirty" -> "Built from modified, uncommitted source."
        else -> "Custom tag from the vendor or builder; no standard meaning."
    }
}
