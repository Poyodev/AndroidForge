package example.sysinfo.app

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val tabNames = listOf("System", "Live", "SoC", "Display", "Memory", "Storage", "Battery",
        "Thermal", "Sensors", "Network", "Camera", "Bench", "History", "About")
    private val liveTabs = setOf("Live", "SoC", "Memory", "Battery", "Thermal", "Sensors", "Network")

    private lateinit var list: LinearLayout
    private var tab = "System"
    private var status: TextView? = null
    private val shown = ArrayList<Row>()
    private val valueViews = ArrayList<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, Prefs.interval(this@MainActivity) * 1000L)
        }
    }
    @Volatile private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.list)
        val tb = findViewById<MaterialToolbar>(R.id.toolbar)
        tb.inflateMenu(R.menu.top)
        tb.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_pdf) { askPdf(); true } else false
        }
        val tabs = findViewById<TabLayout>(R.id.tabs)
        for (n in tabNames) tabs.addTab(tabs.newTab().setText(n))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { tab = tabNames[t.position]; render() }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) { render() }
        })
        render()
    }

    override fun onResume() {
        super.onResume()
        if (tab == "Sensors") SensorLive.start(this)
        handler.postDelayed(tick, Prefs.interval(this) * 1000L)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        SensorLive.stop()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun rowsFor(t: String): List<Row>? = when (t) {
        "System" -> Info.system()
        "Live" -> Live.rows(this)
        "SoC" -> Soc.rows(this)
        "Display" -> Hw.display(this)
        "Memory" -> Hw.memory(this)
        "Storage" -> Hw.storage(this)
        "Battery" -> Hw.battery(this)
        "Thermal" -> Hw.thermal(this)
        "Sensors" -> Sensors.rows(this, true)
        "Network" -> Net.rows(this)
        "Camera" -> Cam.rows(this)
        else -> null
    }

    private fun render() {
        list.removeAllViews()
        status = null
        shown.clear()
        valueViews.clear()
        if (tab == "Sensors") SensorLive.start(this) else SensorLive.stop()
        val rows = rowsFor(tab)
        if (rows != null) {
            val vis = visible(rows)
            if (vis.isEmpty()) addNote("Nothing to show here: this phone does not expose this data to apps.") else addRows(vis)
        } else if (tab == "Bench") benchTab()
        else if (tab == "History") historyTab()
        else aboutTab()
    }

    /** Updates values in place so the list does not jump. Rebuilds only when the set of rows changes. */
    private fun refresh() {
        if (tab !in liveTabs) return
        val rows = visible(rowsFor(tab) ?: return)
        if (rows.size == shown.size && rows.indices.all { rows[it].label == shown[it].label }) {
            for (i in rows.indices) { shown[i] = rows[i]; valueViews[i].text = rows[i].value }
        } else render()
    }

    private fun addRows(rows: List<Row>) {
        for (r in rows) {
            val idx = shown.size
            shown.add(r)
            val v = layoutInflater.inflate(R.layout.item_row, list, false)
            v.findViewById<TextView>(R.id.label).text = r.label
            val value = v.findViewById<TextView>(R.id.value)
            value.text = r.value
            valueViews.add(value)
            v.setOnClickListener { show(shown[idx]) }
            list.addView(v)
        }
    }

    private fun addNote(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setPadding(dp(16), dp(12), dp(16), dp(4))
        t.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
        list.addView(t)
        return t
    }

    private fun addButton(text: String, onClick: () -> Unit) {
        val b = MaterialButton(this)
        b.text = text
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(dp(16), dp(8), dp(16), dp(8))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        list.addView(b)
    }

    private fun show(r: Row) {
        MaterialAlertDialogBuilder(this)
            .setTitle(r.label)
            .setMessage(r.parts.joinToString("\n\n") { it.piece + "\n" + it.meaning })
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------- About ----------

    private fun aboutTab() {
        addNote("SysInfo 0.4\nAn AIDA64-style system information app. Tap any value to see what it means.")
        addNote("Temperature unit")
        val g = MaterialButtonToggleGroup(this)
        g.isSingleSelection = true
        g.isSelectionRequired = true
        val bc = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        bc.text = "°C"
        bc.id = View.generateViewId()
        val bf = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        bf.text = "°F"
        bf.id = View.generateViewId()
        g.addView(bc)
        g.addView(bf)
        g.check(if (Prefs.useF(this)) bf.id else bc.id)
        g.addOnButtonCheckedListener { _, id, checked -> if (checked) Prefs.setUseF(this, id == bf.id) }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.setMargins(dp(16), dp(8), dp(16), dp(8))
        g.layoutParams = lp
        list.addView(g)

        val lbl = addNote("Update every " + Prefs.interval(this) + " s (live tabs)")
        val s = Slider(this)
        s.valueFrom = 1f
        s.valueTo = 10f
        s.stepSize = 1f
        s.value = Prefs.interval(this).toFloat()
        s.addOnChangeListener { _, v, _ ->
            Prefs.setInterval(this, v.toInt())
            lbl.text = "Update every " + v.toInt() + " s (live tabs)"
        }
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.setMargins(dp(16), 0, dp(16), dp(8))
        s.layoutParams = sp
        list.addView(s)

        addNote("What is shown: only data your phone exposes to normal apps. Rows that cannot be read are hidden. If the GPU clock and load are hidden, the Advertised GPU row still shows the chip maker's clock and branding.")
        addNote("Privacy: the app has no internet permission and never reads IMEI or phone number. The PDF export also leaves out your local IP address and Wi-Fi name.")
        addNote("Chip database: assets/socs.csv and assets/families.csv. They are plain text, so you can add chips yourself.")
    }

    // ---------- Bench ----------

    private fun benchTab() {
        addNote("Integer + float loop test, 3 s single-core then 3 s multi-core. Scores are millions of loop iterations per second and only compare between SysInfo users, not with other benchmark apps.")
        status = addNote(if (running) "Running…" else "Ready.")
        addButton("Run CPU benchmark") { runBench() }
        val last = History.load(this).maxByOrNull { it.ts }
        if (last != null) {
            addRows(listOf(Row("Last result", "Single %.1f · Multi %.1f".format(last.single, last.multi),
                listOf(Part("Single / Multi", "Single uses one thread; multi uses one thread per core (" + last.cores + ")")))))
        }
    }

    private fun runBench() {
        if (running) return
        running = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            val r = Bench.run { s -> runOnUiThread { status?.text = s } }
            History.add(this, History.Entry(System.currentTimeMillis(), Build.MANUFACTURER + " " + Build.MODEL,
                Build.HARDWARE, Runtime.getRuntime().availableProcessors(), r.first, r.second))
            runOnUiThread {
                running = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (tab == "Bench") render()
            }
        }.start()
    }

    // ---------- History / leaderboard ----------

    private fun historyTab() {
        addNote("Leaderboard sorted by multi-core score. Share it as JSON; friends paste it in with Import to merge.")
        addButton("Export / share") {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, History.toJson(History.load(this)))
            startActivity(Intent.createChooser(i, "Share leaderboard"))
        }
        addButton("Import from clipboard") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            val n = History.merge(this, text)
            Toast.makeText(this, if (n < 0) "Clipboard is not a SysInfo leaderboard" else "Added $n entries", Toast.LENGTH_SHORT).show()
            render()
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val rows = History.load(this).sortedByDescending { it.multi }.mapIndexed { i, e ->
            Row("#" + (i + 1) + " " + e.device,
                "Multi %.1f · Single %.1f · %d cores".format(e.multi, e.single, e.cores),
                listOf(Part(e.soc, "Platform name; run on " + fmt.format(Date(e.ts)) + ".")))
        }
        if (rows.isEmpty()) addNote("No results yet. Run a benchmark first.") else addRows(rows)
    }

    // ---------- PDF ----------

    private fun askPdf() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/pdf").putExtra(Intent.EXTRA_TITLE, "SysInfo-specs.pdf")
        startActivityForResult(i, 42)
    }

    @Deprecated("Fine on API 23+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 42 && resultCode == RESULT_OK && uri != null) {
            val ok = try {
                contentResolver.openOutputStream(uri)?.use { Specs.writePdf(this, it) }
                true
            } catch (e: Exception) { false }
            Toast.makeText(this, if (ok) "PDF saved" else "Could not write PDF", Toast.LENGTH_SHORT).show()
        }
    }
}
