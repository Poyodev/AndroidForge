package example.sysinfo.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun useF(c: Context) = p(c).getBoolean("f", false)
    fun setUseF(c: Context, v: Boolean) { p(c).edit().putBoolean("f", v).apply() }
    fun interval(c: Context) = p(c).getInt("sec", 2)
    fun setInterval(c: Context, v: Int) { p(c).edit().putInt("sec", v).apply() }

    /** Formats a Celsius value in the unit chosen in About. */
    fun t(c: Context, celsius: Double): String =
        if (useF(c)) "%.1f °F".format(celsius * 9 / 5 + 32) else "%.1f °C".format(celsius)
}
