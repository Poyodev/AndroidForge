package example.sysinfo.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Pure JVM integer+float loop, so one APK works on ARMv7 and ARMv8. Scores compare between SysInfo users only. */
object Bench {
    @Volatile private var sink = 0L

    private fun chunk(seed: Long): Long {
        var a = seed
        var f = 1.0001
        for (i in 1..50_000) {
            a = a * 6364136223846793005L + 1442695040888963407L
            a = a xor (a ushr 29)
            f = f * 1.0000001 + (i and 7) * 1e-9
            if (f > 2.0) f -= 1.0
        }
        return a + f.toLong()
    }

    private fun runFor(threads: Int, ms: Long): Double {
        val deadline = System.nanoTime() + ms * 1_000_000L
        val counts = LongArray(threads)
        val ts = (0 until threads).map { t ->
            Thread {
                var n = 0L
                var s = t.toLong() + 1
                while (System.nanoTime() < deadline) { s = chunk(s); n++ }
                counts[t] = n
                sink = s
            }
        }
        ts.forEach { it.start() }
        ts.forEach { it.join() }
        return counts.sum() * 50_000.0 / (ms / 1000.0) / 1e6
    }

    /** Returns (single, multi) in millions of loop iterations per second. */
    fun run(onStage: (String) -> Unit): Pair<Double, Double> {
        onStage("Warming up…")
        runFor(1, 500)
        onStage("Single-core test…")
        val single = runFor(1, 3000)
        onStage("Multi-core test…")
        val multi = runFor(Runtime.getRuntime().availableProcessors(), 3000)
        return Pair(single, multi)
    }
}

object History {
    class Entry(val ts: Long, val device: String, val soc: String, val cores: Int, val single: Double, val multi: Double) {
        fun json(): JSONObject = JSONObject().put("ts", ts).put("device", device).put("soc", soc)
            .put("cores", cores).put("single", single).put("multi", multi)
    }

    private fun prefs(c: Context) = c.getSharedPreferences("hist", Context.MODE_PRIVATE)

    private fun parse(a: JSONArray): MutableList<Entry> {
        val out = ArrayList<Entry>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Entry(o.optLong("ts"), o.optString("device", "?"), o.optString("soc", ""),
                o.optInt("cores"), o.optDouble("single", 0.0), o.optDouble("multi", 0.0)))
        }
        return out
    }

    fun load(c: Context): MutableList<Entry> = try {
        parse(JSONArray(prefs(c).getString("j", "[]")))
    } catch (e: Exception) { ArrayList<Entry>() }

    private fun save(c: Context, list: List<Entry>) {
        prefs(c).edit().putString("j", JSONArray(list.map { it.json() }).toString()).apply()
    }

    fun add(c: Context, e: Entry) { val l = load(c); l.add(e); save(c, l) }

    fun toJson(list: List<Entry>): String = JSONObject().put("app", "SysInfoBench").put("v", 1)
        .put("entries", JSONArray(list.map { it.json() })).toString(2)

    /** Merges shared leaderboard JSON. Returns the number of new entries, or -1 if the text is not valid. */
    fun merge(c: Context, text: String): Int {
        val t = text.trim()
        val arr = try {
            if (t.startsWith("[")) JSONArray(t) else JSONObject(t).getJSONArray("entries")
        } catch (e: Exception) { return -1 }
        val cur = load(c)
        val keys = cur.map { "${it.ts}|${it.device}" }.toHashSet()
        var n = 0
        for (e in parse(arr)) {
            if (e.ts > 0 && keys.add("${e.ts}|${e.device}")) { cur.add(e); n++ }
        }
        save(c, cur)
        return n
    }
}
