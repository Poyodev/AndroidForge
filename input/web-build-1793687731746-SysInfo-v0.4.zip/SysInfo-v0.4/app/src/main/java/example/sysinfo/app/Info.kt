package example.sysinfo.app

import android.content.Context
import android.os.Build
import java.io.File

typealias Part = KernelDecoder.Part

/** pdf = false keeps the row out of the exported PDF (IP address, Wi-Fi name). A value of "unavailable" hides the row. */
class Row(val label: String, val value: String, val parts: List<Part>, val pdf: Boolean = true)

fun r(label: String, value: String?, meaning: String, pdf: Boolean = true): Row {
    val v = if (value.isNullOrBlank()) "unavailable" else value
    return Row(label, v, listOf(Part(v, meaning)), pdf)
}

fun visible(rows: List<Row>): List<Row> = rows.filter { it.value != "unavailable" }

object Info {
    private fun simple(label: String, value: String?, meaning: String): Row {
        val v = if (value.isNullOrBlank()) "unavailable" else value
        return Row(label, v, listOf(KernelDecoder.Part(v, meaning)))
    }

    fun system(): List<Row> {
        val rel = System.getProperty("os.version") ?: ""
        val full = try { File("/proc/version").readText().trim() } catch (e: Exception) { "" }
        val src = if (full.isNotEmpty()) full else rel
        val out = ArrayList<Row>()
        out.add(simple("Model", Build.MODEL, "Marketing model name set by the manufacturer (ro.product.model)."))
        out.add(simple("Manufacturer", Build.MANUFACTURER, "Company that built the phone (ro.product.manufacturer)."))
        out.add(simple("Device", Build.DEVICE, "Internal device codename used by the ROM (ro.product.device)."))
        out.add(simple("Hardware", Build.HARDWARE, "Chipset or platform name the kernel reports, e.g. mt6765 (ro.hardware)."))
        out.add(simple("Board", Build.BOARD, "Main board name (ro.product.board). Often matches the SoC family."))
        if (Build.VERSION.SDK_INT >= 31) {
            out.add(simple("SoC", Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL, "The chip's maker and model as reported by Android 12+."))
        }
        out.add(simple("Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")",
            "Android version people know, then the API level apps are built against."))
        out.add(simple("Security patch", Build.VERSION.SECURITY_PATCH, "Date of the newest Android security fixes in this build."))
        out.add(simple("Build ID", Build.ID, "Google-style build code, e.g. TP1A.220624.014."))
        out.add(simple("Fingerprint", Build.FINGERPRINT,
            "Unique build label: brand/product/device:release/build id/incremental:type/tags."))
        out.add(simple("Supported ABIs", Build.SUPPORTED_ABIS.joinToString(", "),
            "CPU instruction sets, best first. arm64-v8a is 64-bit ARM (ARMv8), armeabi-v7a is 32-bit ARM (ARMv7)."))
        out.add(Row("Kernel", if (rel.isEmpty()) "unavailable" else rel, KernelDecoder.decode(src)))
        out.add(Row("Kernel (full)", if (full.isEmpty()) "unavailable" else full, KernelDecoder.decode(src)))
        return out
    }
}
