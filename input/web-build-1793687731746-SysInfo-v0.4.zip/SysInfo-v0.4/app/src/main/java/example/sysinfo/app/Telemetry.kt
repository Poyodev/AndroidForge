package example.sysinfo.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.telephony.TelephonyManager
import java.net.Inet4Address
import java.net.NetworkInterface

/** Network telemetry. Never reads IMEI or phone number, and keeps the local IP and Wi-Fi name out of the PDF. */
object Net {
    private var t0 = 0L
    private var rx0 = 0L
    private var tx0 = 0L

    fun speeds(): Pair<Double, Double>? {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0 || tx < 0) return null
        val now = SystemClock.elapsedRealtime()
        val s = if (t0 > 0 && now > t0) Pair((rx - rx0) * 1000.0 / (now - t0), (tx - tx0) * 1000.0 / (now - t0)) else null
        t0 = now; rx0 = rx; tx0 = tx
        return s
    }

    fun rate(b: Double): String = if (b >= 1048576) "%.1f MB/s".format(b / 1048576) else "%.0f KB/s".format(b / 1024)
    private fun mb(b: Long) = "%.1f MB".format(b / 1048576.0)

    private fun std(n: Int) = when (n) {
        1 -> "802.11a/b/g"; 4 -> "Wi-Fi 4 (802.11n)"; 5 -> "Wi-Fi 5 (802.11ac)"
        6 -> "Wi-Fi 6 (802.11ax)"; 7 -> "802.11ad"; 8 -> "Wi-Fi 7 (802.11be)"; else -> ""
    }

    @Suppress("DEPRECATION")
    fun rows(c: Context): List<Row> {
        val out = ArrayList<Row>()
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } } catch (e: Exception) { null }
        val kinds = ArrayList<String>()
        if (caps != null) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) kinds.add("Wi-Fi")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) kinds.add("Cellular")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) kinds.add("Ethernet")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) kinds.add("VPN")
        }
        out.add(r("Connection", if (kinds.isEmpty()) "Offline" else kinds.joinToString(" + "), "The kind of network carrying your traffic right now."))
        if (caps != null) {
            out.add(r("Internet check", if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "Verified" else "Not verified",
                "Android tests whether the network really reaches the internet."))
            out.add(r("Metered", if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) "No" else "Yes",
                "A metered connection (usually mobile data) makes Android limit background transfers."))
            if (caps.linkDownstreamBandwidthKbps > 0) out.add(r("Downlink estimate", "%.0f Mbps".format(caps.linkDownstreamBandwidthKbps / 1000.0),
                "The network's own estimate of its download capacity, not a speed test."))
            if (caps.linkUpstreamBandwidthKbps > 0) out.add(r("Uplink estimate", "%.0f Mbps".format(caps.linkUpstreamBandwidthKbps / 1000.0),
                "The network's own estimate of its upload capacity, not a speed test."))
        }
        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            val info = try { (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo } catch (e: Exception) { null }
            if (info != null) {
                if (info.rssi > -127) out.add(r("Wi-Fi signal", info.rssi.toString() + " dBm",
                    "Received signal strength. Closer to 0 is better: -50 is excellent, -70 is fair, -85 is poor."))
                if (info.linkSpeed > 0) out.add(r("Wi-Fi link speed", info.linkSpeed.toString() + " Mbps", "Negotiated radio speed with the router."))
                if (info.frequency > 0) {
                    val band = if (info.frequency >= 5925) "6 GHz" else if (info.frequency >= 4900) "5 GHz" else "2.4 GHz"
                    out.add(r("Wi-Fi band", band + " (" + info.frequency + " MHz)", "Radio band in use. 5 and 6 GHz are faster but have shorter range."))
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    val s = std(info.wifiStandard)
                    if (s.isNotEmpty()) out.add(r("Wi-Fi standard", s, "The Wi-Fi generation of this connection."))
                }
                val ssid = info.ssid?.trim('"')
                if (!ssid.isNullOrBlank() && ssid != "<unknown ssid>") out.add(r("Wi-Fi name", ssid, "Network name. Never written to the PDF.", false))
            }
        }
        val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        if (tm != null) {
            val op = try { tm.networkOperatorName } catch (e: Exception) { "" }
            if (!op.isNullOrBlank()) out.add(r("Carrier", op, "Name of the mobile network the phone is registered on."))
            if (try { tm.isNetworkRoaming } catch (e: Exception) { false }) out.add(r("Roaming", "Yes", "The phone is on a partner network away from its home carrier."))
        }
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx >= 0) out.add(r("Received since boot", mb(rx), "Total data downloaded over all networks since the phone started."))
        if (tx >= 0) out.add(r("Sent since boot", mb(tx), "Total data uploaded over all networks since the phone started."))
        speeds()?.let {
            out.add(r("Live speed", "↓ " + rate(it.first) + "  ↑ " + rate(it.second), "Traffic over the last update interval, all apps combined."))
        }
        try {
            val list = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
            loop@ for (ni in list) {
                if (ni.isLoopback || !ni.isUp) continue
                for (a in ni.inetAddresses.toList()) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        out.add(r("Local IP", a.hostAddress, "Address on your local network. Never written to the PDF.", false))
                        break@loop
                    }
                }
            }
        } catch (e: Exception) { }
        return out
    }
}

/** Keeps the latest reading of every sensor while the Sensors tab is open, and nothing otherwise. */
object SensorLive : SensorEventListener {
    private val last = HashMap<Sensor, FloatArray>()
    private var sm: SensorManager? = null
    private var active = false

    fun start(c: Context) {
        if (active) return
        val m = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm = m
        last.clear()
        for (s in m.getSensorList(Sensor.TYPE_ALL)) {
            try { m.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL) } catch (e: Exception) { }
        }
        active = true
    }

    fun stop() {
        if (!active) return
        sm?.unregisterListener(this)
        active = false
    }

    override fun onSensorChanged(e: SensorEvent) { last[e.sensor] = e.values.clone() }
    override fun onAccuracyChanged(s: Sensor, a: Int) {}

    fun text(c: Context, s: Sensor, type: String): String? {
        val v = last[s] ?: return null
        if (v.isEmpty()) return null
        return when (type) {
            "ambient_temperature" -> Prefs.t(c, v[0].toDouble())
            "step_counter" -> "%.0f steps".format(v[0])
            else -> {
                val unit = when (type) {
                    "accelerometer", "gravity", "linear_acceleration" -> " m/s²"
                    "gyroscope" -> " rad/s"
                    "magnetic_field" -> " µT"
                    "light" -> " lx"
                    "proximity" -> " cm"
                    "pressure" -> " hPa"
                    "relative_humidity" -> " %"
                    else -> ""
                }
                v.take(3).joinToString("  ") { "%.2f".format(it) } + unit
            }
        }
    }
}

object Sensors {
    private val INFO = mapOf(
        "accelerometer" to "Measures acceleration including gravity. Used for rotation, step counting and shake.",
        "gyroscope" to "Measures rotation speed on three axes. Used for games, VR and camera stabilisation.",
        "magnetic_field" to "Compass sensor. Measures the surrounding magnetic field.",
        "light" to "Ambient light sensor. Drives auto-brightness.",
        "proximity" to "Detects when something is close to the screen, for example your ear during a call.",
        "pressure" to "Barometer. Used for altitude and weather hints.",
        "gravity" to "Accelerometer data with motion removed, leaving only the pull of gravity.",
        "linear_acceleration" to "Accelerometer data with gravity removed, leaving only motion.",
        "rotation_vector" to "Fused orientation from accelerometer, gyroscope and compass.",
        "game_rotation_vector" to "Orientation without the compass, immune to magnetic interference.",
        "relative_humidity" to "Air humidity sensor.",
        "ambient_temperature" to "Air temperature sensor.",
        "step_counter" to "Steps since boot, counted by low-power hardware.",
        "step_detector" to "Fires once per step.",
        "significant_motion" to "Fires once when you start moving a lot. Event-driven, so it rarely shows a value.",
        "heart_rate" to "Optical heart-rate sensor. Needs a body-sensors permission this app does not request."
    )

    fun rows(c: Context, live: Boolean): List<Row> {
        val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val out = ArrayList<Row>()
        for (s in sm.getSensorList(Sensor.TYPE_ALL).sortedBy { it.type }) {
            val t = s.stringType.removePrefix("android.sensor.")
            val v = if (live) (SensorLive.text(c, s, t) ?: "idle") else t
            val parts = ArrayList<Part>()
            parts.add(Part(t, INFO[t] ?: "Sensor type $t."))
            parts.add(Part("Vendor", s.vendor))
            parts.add(Part("Power use", "%.2f mA while active".format(s.power)))
            parts.add(Part("Range", "Max %.1f, resolution %.4f".format(s.maximumRange, s.resolution)))
            if (s.minDelay > 0) parts.add(Part("Fastest rate", (1000000 / s.minDelay).toString() + " Hz"))
            out.add(Row(s.name, v, parts))
        }
        return out
    }
}

/** Camera2 probe: reads characteristics only. No camera permission, nothing is opened. */
object Cam {
    private fun level(n: Int?): String? = when (n) {
        0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> null
    }

    private val CAPS = mapOf(
        1 to "Manual sensor", 2 to "Manual post-processing", 3 to "RAW capture", 6 to "Burst capture",
        8 to "Depth output", 9 to "High-speed video", 11 to "Logical multi-camera", 12 to "Monochrome",
        16 to "Ultra high resolution sensor", 18 to "10-bit HDR"
    )

    fun rows(c: Context): List<Row> {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids = try { cm.cameraIdList } catch (e: Exception) { return emptyList() }
        val out = ArrayList<Row>()
        out.add(r("Camera2 probe", ids.size.toString() + " camera ids",
            "Reads each camera's characteristics through the Camera2 API. No camera permission is needed and nothing is opened or recorded."))
        for (id in ids) {
            val ch = try { cm.getCameraCharacteristics(id) } catch (e: Exception) { continue }
            val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "front"
                CameraCharacteristics.LENS_FACING_BACK -> "back"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "external"
                else -> ""
            }
            val px = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
            val mm = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val ap = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull()
            val fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val lv = level(ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL))
            val mp = px?.let { it.width * it.height / 1e6 }
            val eq = if (fl != null && mm != null)
                fl * 43.27 / Math.sqrt((mm.width * mm.width + mm.height * mm.height).toDouble()) else null

            val parts = ArrayList<Part>()
            if (px != null) parts.add(Part("%.1f MP".format(mp), "Sensor pixel array " + px.width + " x " + px.height + ". Phones often bin pixels, so photos can be smaller."))
            if (mm != null) parts.add(Part("%.2f x %.2f mm".format(mm.width, mm.height), "Physical sensor size. Bigger sensors collect more light."))
            if (ap != null) parts.add(Part("f/%.1f".format(ap), "Lens aperture. A smaller f-number lets in more light."))
            if (fl != null) parts.add(Part("%.2f mm".format(fl), "Real focal length." + (if (eq != null) " About %.0f mm in 35 mm terms.".format(eq) else "")))
            ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let {
                parts.add(Part("ISO " + it.lower + " to " + it.upper, "Sensor sensitivity range for manual control."))
            }
            ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let {
                parts.add(Part("1/" + (1e9 / it.lower).toInt() + " s to %.1f s".format(it.upper / 1e9), "Shortest and longest manual exposure."))
            }
            val min = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)
            if (min != null && min > 0f) parts.add(Part("%.0f cm".format(100f / min), "Closest focusing distance. Fixed-focus lenses report nothing here."))
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) parts.add(Part("Flash", "This camera has a flash unit."))
            if (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(1) == true) {
                parts.add(Part("OIS", "Optical image stabilisation: the lens or sensor physically moves against shake."))
            }
            ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.let { arr ->
                val names = arr.mapNotNull { CAPS[it] }
                if (names.isNotEmpty()) parts.add(Part(names.joinToString(", "), "Camera2 capabilities this camera reports."))
            }
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width * it.height }?.let {
                parts.add(Part("JPEG up to " + it.width + " x " + it.height, "Largest still-photo size the camera pipeline offers."))
            }
            map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { it.width * it.height }?.let {
                parts.add(Part("RAW up to " + it.width + " x " + it.height, "Largest RAW (DNG) size, if RAW capture is exposed."))
            }
            if (Build.VERSION.SDK_INT >= 28) {
                val phys = ch.physicalCameraIds
                if (phys.isNotEmpty()) parts.add(Part("Logical camera of " + phys.joinToString(", "), "This id fuses several physical lenses; the ids are the individual cameras."))
            }
            if (lv != null) parts.add(0, Part("Camera2 level $lv",
                "LEGACY wraps the old Camera1 driver, and Google Camera ports usually fail there. LIMITED is basic Camera2. FULL adds manual control. LEVEL_3 adds more reprocessing. Camera ports work best on FULL or LEVEL_3 with RAW."))

            val value = listOfNotNull(mp?.let { "%.1f MP".format(it) }, ap?.let { "f/%.1f".format(it) },
                eq?.let { "%.0f mm eq".format(it) }, lv).joinToString(" · ")
            if (value.isNotEmpty()) out.add(Row("Camera $id" + (if (facing.isNotEmpty()) " · $facing" else ""), value, parts))
        }
        return out
    }
}

/** Dashboard of the numbers that change while you watch. Rows appear only when the phone exposes them. */
object Live {
    fun rows(c: Context): List<Row> {
        val out = ArrayList<Row>()
        val load = CpuLoad.sample()
        if (load.isNotEmpty()) {
            val avg = load.values.sum() / load.size
            val top = load.maxByOrNull { it.value }
            out.add(Row("CPU load", "$avg %", listOfNotNull(
                Part("Average", "Mean busy time across all online cores since the last update."),
                top?.let { Part("Busiest core", "Core " + it.key + " at " + it.value + " %") })))
        }
        val fastest = Cpu.read().map { it.curKhz }.filter { it > 0 }.maxOrNull()
        if (fastest != null) out.add(r("CPU clock", (fastest / 1000).toString() + " MHz (fastest core)", "Current frequency of the fastest online core."))
        val g = Gpu.curMhz()
        val gb = Gpu.busyPct()
        if (g > 0) out.add(r("GPU clock", "$g MHz", "Live GPU frequency."))
        if (gb != null) out.add(r("GPU load", "$gb %", "How busy the GPU was over the last sample."))

        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.totalMem > 0) {
            val used = mi.totalMem - mi.availMem
            out.add(r("RAM used", (used * 100 / mi.totalMem).toString() + " % (" + "%.1f".format(used / 1073741824.0) + " of " + "%.1f".format(mi.totalMem / 1073741824.0) + " GB)",
                "Memory in use, not counting what Android can reclaim instantly."))
        }

        val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bi != null) {
            val lv = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val mv = bi.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            val cur = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            val sb = StringBuilder()
            if (lv >= 0) sb.append(lv * 100 / sc).append(" %")
            if (cur != Int.MIN_VALUE && cur != 0) {
                val ma = if (Math.abs(cur) < 20000) cur else cur / 1000
                sb.append(" · ").append(ma).append(" mA")
                if (mv > 0) sb.append(" · ").append("%.1f W".format(Math.abs(ma) * mv / 1e6))
            }
            out.add(r("Battery", sb.toString(), "Level, current (sign and unit vary by phone) and power draw worked out from current times voltage."))
        }

        val hot = Hw.zones().maxByOrNull { it.deg }
        if (hot != null) out.add(r("Hottest sensor", hot.name + " · " + Prefs.t(c, hot.deg), "The warmest thermal zone this phone exposes."))
        else Hw.batteryTempC(c)?.let { out.add(r("Battery temperature", Prefs.t(c, it), "The only temperature this phone exposes to apps.")) }
        if (Build.VERSION.SDK_INT >= 29) {
            val st = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
            val names = listOf("None", "Light", "Moderate", "Severe", "Critical", "Emergency", "Shutdown")
            if (st in names.indices) out.add(r("Throttle status", names[st], "Android's own heat verdict. None is normal."))
        }
        Net.speeds()?.let { out.add(r("Network", "↓ " + Net.rate(it.first) + "  ↑ " + Net.rate(it.second), "Traffic over the last update interval, all apps combined.")) }
        return out
    }
}
