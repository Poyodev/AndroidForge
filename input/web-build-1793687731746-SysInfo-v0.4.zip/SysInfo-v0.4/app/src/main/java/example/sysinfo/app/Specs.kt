package example.sysinfo.app

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Specs {
    private val DETAIL = setOf("Kernel (full)", "Chip")

    private fun section(out: MutableList<String>, name: String, rows: List<Row>) {
        val ok = visible(rows).filter { it.pdf }
        if (ok.isEmpty()) return
        out.add("")
        out.add("== $name ==")
        for (r in ok) {
            out.add(r.label + ": " + r.value)
            if (r.label in DETAIL) for (p in r.parts) out.add("   - " + p.piece + ": " + p.meaning)
        }
    }

    fun lines(c: Context): List<String> {
        val out = ArrayList<String>()
        out.add("Generated " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
        out.add("Left out on purpose: IMEI, phone number, local IP address and Wi-Fi name.")
        section(out, "System", Info.system())
        section(out, "SoC", Soc.rows(c))
        section(out, "Display", Hw.display(c))
        section(out, "Memory", Hw.memory(c))
        section(out, "Storage", Hw.storage(c))
        section(out, "Battery", Hw.battery(c))
        section(out, "Thermal", Hw.thermal(c))
        section(out, "Sensors", Sensors.rows(c, false))
        section(out, "Network", Net.rows(c))
        section(out, "Camera", Cam.rows(c))
        val last = History.load(c).maxByOrNull { it.ts }
        if (last != null) {
            out.add("")
            out.add("== Latest benchmark ==")
            out.add("Single-core: %.1f   Multi-core: %.1f   (%d cores)".format(last.single, last.multi, last.cores))
        }
        return out
    }

    fun writePdf(c: Context, out: OutputStream) {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 10f; isAntiAlias = true }
        val head = Paint(paint).apply { textSize = 16f; isFakeBoldText = true }
        val w = 595
        val h = 842
        val m = 40f
        var page: PdfDocument.Page? = null
        var y = 0f
        var n = 0
        fun newPage() {
            page?.let { doc.finishPage(it) }
            n++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
            y = m + 10f
        }
        newPage()
        page!!.canvas.drawText("SysInfo specs", m, y, head)
        y += 24f
        for (line in lines(c)) {
            if (line.isEmpty()) { y += 7f; continue }
            var s = line
            while (s.isNotEmpty()) {
                if (y > h - m) newPage()
                val cnt = paint.breakText(s, true, w - 2 * m, null).coerceAtLeast(1)
                page!!.canvas.drawText(s, 0, cnt, m, y, paint)
                y += 14f
                s = s.substring(cnt)
            }
        }
        page?.let { doc.finishPage(it) }
        doc.writeTo(out)
        doc.close()
    }
}
