package example.sysinfo.app

import android.content.Context
import android.os.Build
import java.io.File

object Props {
    private val cache = HashMap<String, String>()
    fun get(k: String): String = cache.getOrPut(k) {
        try {
            val p = Runtime.getRuntime().exec(arrayOf("getprop", k))
            val s = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            s
        } catch (e: Exception) { "" }
    }
}

/** Names each core from /proc/cpuinfo. Same code path on ARMv7 and ARMv8. */
object Cpu {
    class Core(val idx: Int, val implementer: Int, val part: Int, val maxKhz: Long, val curKhz: Long, val gov: String)

    private val ARM = mapOf(
        0xc05 to "Cortex-A5", 0xc07 to "Cortex-A7", 0xc09 to "Cortex-A9", 0xc0e to "Cortex-A17", 0xc0f to "Cortex-A15",
        0xd03 to "Cortex-A53", 0xd04 to "Cortex-A35", 0xd05 to "Cortex-A55", 0xd07 to "Cortex-A57", 0xd08 to "Cortex-A72",
        0xd09 to "Cortex-A73", 0xd0a to "Cortex-A75", 0xd0b to "Cortex-A76", 0xd0d to "Cortex-A77", 0xd41 to "Cortex-A78",
        0xd44 to "Cortex-X1", 0xd46 to "Cortex-A510", 0xd47 to "Cortex-A710", 0xd48 to "Cortex-X2", 0xd4d to "Cortex-A715",
        0xd4e to "Cortex-X3", 0xd80 to "Cortex-A520", 0xd81 to "Cortex-A720", 0xd82 to "Cortex-X4",
        0xd85 to "Cortex-X925", 0xd87 to "Cortex-A725"
    )
    private val QCOM = mapOf(
        0x800 to "Kryo 2XX Gold (Cortex-A73)", 0x801 to "Kryo 2XX Silver (Cortex-A53)",
        0x802 to "Kryo 3XX Gold (Cortex-A75)", 0x803 to "Kryo 3XX Silver (Cortex-A55)",
        0x804 to "Kryo 4XX Gold (Cortex-A76)", 0x805 to "Kryo 4XX Silver (Cortex-A55)"
    )

    fun isQualcomm(): Boolean =
        Build.HARDWARE.lowercase() == "qcom" ||
            (Build.VERSION.SDK_INT >= 31 && Build.SOC_MANUFACTURER.equals("Qualcomm", true))

    private fun nameOf(impl: Int, part: Int): String = when (impl) {
        0x41 -> ARM[part] ?: "ARM part 0x%x".format(part)
        0x51 -> QCOM[part] ?: "Qualcomm part 0x%x".format(part)
        else -> "Implementer 0x%x part 0x%x".format(impl, part)
    }

    fun label(c: Core, qcom: Boolean): String {
        val base = nameOf(c.implementer, c.part)
        return if (c.implementer == 0x41 && qcom) "$base (Kryo-branded)" else base
    }

    fun note(c: Core, qcom: Boolean): String = when (c.implementer) {
        0x51 -> "Qualcomm sells these cores as Kryo. The number (2XX, 3XX, 4XX) is Qualcomm's generation; the Cortex name is the ARM design it is derived from."
        0x41 -> if (qcom) "Plain ARM core design. Qualcomm brands its newer chips as Kryo too."
                else "Standard ARM core design, used as-is by the chip maker."
        else -> "Unknown implementer; the chip maker uses its own core design."
    }

    fun explain(c: Core, qcom: Boolean): List<Part> = listOf(
        Part("0x%x / 0x%x".format(c.implementer, c.part),
            "CPU implementer / part from /proc/cpuinfo. 0x41 = ARM, 0x51 = Qualcomm. The part number picks the exact core design."),
        Part(label(c, qcom), note(c, qcom))
    )

    private fun hex(v: String): Int = v.trim().removePrefix("0x").toIntOrNull(16) ?: 0

    private fun freq(idx: Int, name: String): String = try {
        File("/sys/devices/system/cpu/cpu$idx/cpufreq/$name").readText().trim()
    } catch (e: Exception) { "" }

    fun hardwareLine(): String = try {
        File("/proc/cpuinfo").readLines().firstOrNull { it.startsWith("Hardware") }?.substringAfter(':')?.trim() ?: ""
    } catch (e: Exception) { "" }

    fun read(): List<Core> {
        val text = try { File("/proc/cpuinfo").readText() } catch (e: Exception) { return emptyList() }
        val out = ArrayList<Core>()
        var idx = -1
        var impl = 0
        var part = 0
        fun flush() {
            if (idx >= 0) out.add(Core(idx, impl, part, freq(idx, "cpuinfo_max_freq").toLongOrNull() ?: 0L,
                freq(idx, "scaling_cur_freq").toLongOrNull() ?: 0L, freq(idx, "scaling_governor")))
        }
        for (line in text.lines()) {
            val k = line.substringBefore(':').trim()
            val v = line.substringAfter(':', "").trim()
            when (k) {
                "processor" -> { flush(); idx = v.toIntOrNull() ?: -1; impl = 0; part = 0 }
                "CPU implementer" -> impl = hex(v)
                "CPU part" -> part = hex(v)
            }
        }
        flush()
        return out
    }
}

/** Per-core load in percent from /proc/stat deltas. Empty when the file is blocked or on the first call. */
object CpuLoad {
    private var prev = HashMap<Int, LongArray>()

    fun sample(): Map<Int, Int> {
        val now = HashMap<Int, LongArray>()
        try {
            File("/proc/stat").forEachLine { l ->
                if (l.startsWith("cpu") && l.length > 3 && l[3].isDigit()) {
                    val f = l.trim().split(Regex("\\s+"))
                    val v = f.drop(1).mapNotNull { it.toLongOrNull() }
                    if (v.size >= 5) now[f[0].substring(3).toInt()] = longArrayOf(v.sum(), v[3] + v[4])
                }
            }
        } catch (e: Exception) { }
        val out = HashMap<Int, Int>()
        for ((i, n) in now) {
            val p = prev[i] ?: continue
            val dt = n[0] - p[0]
            if (dt > 0) out[i] = (100 - (n[1] - p[1]) * 100 / dt).toInt().coerceIn(0, 100)
        }
        prev = now
        return out
    }
}

/** GPU clock and load from sysfs. Every function returns 0 or null when the phone hides the node. */
object Gpu {
    private fun toMhz(v: Long): Int = when {
        v >= 100_000_000L -> (v / 1_000_000L).toInt()  // Hz
        v >= 10_000L -> (v / 1000L).toInt()            // kHz
        else -> v.toInt()                              // MHz
    }

    private fun num(f: File): Long? = try {
        f.readText().trim().split(Regex("\\s+"))[0].toLong()
    } catch (e: Exception) { null }

    private fun devfreq(file: String): List<File> =
        (File("/sys/class/devfreq").listFiles() ?: emptyArray<File>())
            .filter { val n = it.name.lowercase(); n.contains("mali") || n.contains("gpu") || n.contains("kgsl") }
            .map { File(it, file) }

    private fun first(files: List<File>): Int {
        for (f in files) { val v = num(f); if (v != null && v > 0) return toMhz(v) }
        return 0
    }

    fun maxMhz(): Int = first(devfreq("max_freq") + listOf(File("/sys/class/kgsl/kgsl-3d0/max_gpuclk"), File("/sys/kernel/gpu/gpu_max_clock")))
    fun curMhz(): Int = first(devfreq("cur_freq") + listOf(File("/sys/class/kgsl/kgsl-3d0/gpuclk"), File("/sys/kernel/gpu/gpu_clock")))

    fun busyPct(): Int? {
        num(File("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage"))?.let { return it.toInt().coerceIn(0, 100) }
        try {
            val p = File("/sys/class/kgsl/kgsl-3d0/gpubusy").readText().trim().split(Regex("\\s+"))
            val busy = p[0].toLong()
            val tot = p[1].toLong()
            if (tot > 0) return (busy * 100 / tot).toInt().coerceIn(0, 100)
        } catch (e: Exception) { }
        return null
    }
}

object SocDb {
    class Chip(val platforms: List<String>, val name: String, val cpu: String, val gpu: String,
               val gpuMhz: Int, val process: String, val note: String)
    class Result(val chips: List<Chip>, val narrowed: Boolean)

    private var chipCache: List<Chip>? = null
    private var famCache: List<Pair<String, String>>? = null

    private fun lines(c: Context, f: String): List<String> = try {
        c.assets.open(f).bufferedReader().readLines().filter { it.isNotBlank() && !it.startsWith("#") }
    } catch (e: Exception) { emptyList() }

    private fun all(c: Context): List<Chip> = chipCache ?: lines(c, "socs.csv").mapNotNull { l ->
        val f = l.split(',', limit = 7).map { it.trim() }
        if (f.size < 7) null else Chip(f[0].lowercase().split('|'), f[1], f[2], f[3], f[4].toIntOrNull() ?: 0, f[5], f[6])
    }.also { chipCache = it }

    fun tokens(): List<String> = listOf(
        Props.get("ro.board.platform"), Props.get("ro.hardware"), Props.get("ro.hardware.chipname"),
        Props.get("ro.product.board"), Build.HARDWARE, Build.BOARD, Cpu.hardwareLine(),
        if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else ""
    ).map { it.lowercase().trim() }.filter { it.isNotEmpty() && it != "unknown" }.distinct()

    fun match(c: Context): Result {
        val t = tokens()
        val hits = all(c).filter { ch -> ch.platforms.any { a -> t.any { it == a || it.startsWith(a) } } }
        val mhz = Gpu.maxMhz()
        if (mhz > 0) {
            val near = hits.filter { it.gpuMhz > 0 && Math.abs(it.gpuMhz - mhz) <= 25 }
            if (near.isNotEmpty()) return Result(near, near.size < hits.size)
        }
        return Result(hits, false)
    }

    fun family(c: Context, name: String): Pair<String, String>? {
        val fams = famCache ?: lines(c, "families.csv").mapNotNull { l ->
            val f = l.split(',', limit = 2).map { it.trim() }
            if (f.size < 2) null else Pair(f[0], f[1])
        }.also { famCache = it }
        return fams.filter { name.startsWith(it.first, true) }.maxByOrNull { it.first.length }
    }
}

object Soc {
    private const val ADV = "Specification the chip maker advertises. This is the database value, not a measurement."

    private fun describe(ch: SocDb.Chip): String = listOf(
        if (ch.cpu.isNotEmpty()) "CPU: " + ch.cpu else "",
        if (ch.gpu.isNotEmpty()) "GPU: " + ch.gpu + (if (ch.gpuMhz > 0) " @ " + ch.gpuMhz + " MHz" else "") else "",
        if (ch.process.isNotEmpty()) "Process: " + ch.process else "",
        ch.note
    ).filter { it.isNotEmpty() }.joinToString("\n")

    fun rows(c: Context): List<Row> {
        val out = ArrayList<Row>()
        val tokens = SocDb.tokens()
        val m = SocDb.match(c)
        val chips = m.chips
        if (chips.isNotEmpty()) {
            val parts = ArrayList<Part>()
            if (m.narrowed) parts.add(Part("Narrowed by GPU clock", "The live GPU max clock matched only these entries."))
            else if (chips.map { it.name }.distinct().size > 1) {
                parts.add(Part("Several chips share this platform",
                    "More than one marketing name reports this platform ID (rebadges). The GPU clock and the camera limits tell them apart."))
            }
            chips.forEach { parts.add(Part(it.name, describe(it))) }
            out.add(Row("Chip", chips.map { it.name }.distinct().joinToString(" / "), parts))

            val cpus = chips.map { it.cpu }.filter { it.isNotEmpty() }.distinct()
            if (cpus.isNotEmpty()) out.add(Row("Advertised CPU", cpus.joinToString(" / "), listOf(Part(cpus[0], ADV))))
            val gpus = chips.map { it.gpu }.filter { it.isNotEmpty() }.distinct()
            val clocks = chips.map { it.gpuMhz }.filter { it > 0 }.distinct().sorted()
            if (gpus.isNotEmpty()) {
                val v = gpus.joinToString(" / ") + (if (clocks.isNotEmpty()) " @ " + clocks.joinToString("/") + " MHz" else "")
                out.add(Row("Advertised GPU", v, listOf(Part(v, ADV + " Live GPU clock and load appear below only when this phone exposes them."))))
            }
            val proc = chips.map { it.process }.filter { it.isNotEmpty() }.distinct()
            if (proc.isNotEmpty()) out.add(Row("Process", proc.joinToString(" / "), listOf(Part(proc[0], "Manufacturing node. Smaller numbers are generally more power efficient."))))
            SocDb.family(c, chips[0].name)?.let { out.add(Row("Brand", it.first, listOf(Part(it.first, it.second)))) }
        } else if (tokens.isNotEmpty()) {
            out.add(Row("Platform", tokens[0], listOf(Part("Not in the database yet",
                "Add a line to assets/socs.csv: platform,name,cpu,gpu,gpu_mhz,process,note."))))
        }
        if (tokens.isNotEmpty()) {
            out.add(Row("Platform IDs", tokens.joinToString(", "), listOf(Part(tokens.joinToString(", "),
                "Names the system reports for the chip (ro.board.platform, ro.hardware and similar). The database matches on these."))))
        }

        val cores = Cpu.read()
        val qcom = Cpu.isQualcomm()
        val load = CpuLoad.sample()
        if (cores.isNotEmpty()) {
            val groups = cores.groupBy { Cpu.label(it, qcom) }
            out.add(Row("Cores", cores.size.toString() + ": " + groups.map { "${it.value.size}x ${it.key}" }.joinToString(" + "),
                groups.map { Part("${it.value.size}x ${it.key}", Cpu.note(it.value[0], qcom)) }))
            for (core in cores) {
                val sb = StringBuilder(Cpu.label(core, qcom))
                if (core.curKhz > 0) {
                    sb.append(" · ").append(core.curKhz / 1000)
                    if (core.maxKhz > 0) sb.append(" / ").append(core.maxKhz / 1000)
                    sb.append(" MHz")
                } else if (core.maxKhz > 0) sb.append(" · max ").append(core.maxKhz / 1000).append(" MHz")
                load[core.idx]?.let { sb.append(" · ").append(it).append("%") }
                if (core.gov.isNotEmpty()) sb.append(" · ").append(core.gov)
                out.add(Row("Core " + core.idx, sb.toString(), Cpu.explain(core, qcom)))
            }
        }

        val cur = Gpu.curMhz()
        val max = Gpu.maxMhz()
        val busy = Gpu.busyPct()
        if (cur > 0) out.add(r("GPU clock", "$cur MHz" + (if (max > 0) " / $max MHz" else ""), "Live GPU frequency from sysfs, then the maximum."))
        else if (max > 0) out.add(r("GPU max clock", "$max MHz", "Highest GPU frequency from sysfs. The live value is hidden on this phone."))
        if (busy != null) out.add(r("GPU load", "$busy %", "How busy the GPU was over the last sample."))
        return out
    }
}
