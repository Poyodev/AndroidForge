package example.sysinfo.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

/** The five "quintuplet" tabs: Display, Memory, Storage, Battery, Thermal. */
object Hw {
    private fun row(label: String, value: String?, meaning: String): Row {
        val v = if (value.isNullOrBlank()) "unavailable" else value
        return Row(label, v, listOf(KernelDecoder.Part(v, meaning)))
    }

    private fun size(b: Long): String =
        if (b >= (1L shl 30)) "%.2f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576L)

    // ---------- Display ----------

    private fun bucket(dpi: Int): String = when {
        dpi <= 140 -> "ldpi"
        dpi <= 200 -> "mdpi"
        dpi <= 280 -> "hdpi"
        dpi <= 400 -> "xhdpi"
        dpi <= 560 -> "xxhdpi"
        else -> "xxxhdpi"
    }

    @Suppress("DEPRECATION")
    fun display(c: Context): List<Row> {
        val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = wm.defaultDisplay
        val dm = DisplayMetrics()
        d.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        val inches = Math.sqrt(Math.pow(w / dm.xdpi.toDouble(), 2.0) + Math.pow(h / dm.ydpi.toDouble(), 2.0))
        val out = ArrayList<Row>()
        out.add(row("Resolution", "$w x $h", "Physical pixels, width x height."))
        out.add(row("Density", dm.densityDpi.toString() + " dpi · " + bucket(dm.densityDpi),
            "Pixels per inch Android uses to scale the UI. The bucket (mdpi, xhdpi, xxhdpi...) picks which image set apps load."))
        out.add(row("Physical size", "%.1f inches (estimate)".format(inches),
            "Diagonal worked out from pixels and the dpi the panel reports. Phones often report rounded dpi, so treat it as approximate."))
        out.add(row("Smallest width", "%.0f dp".format(Math.min(w, h) / dm.density),
            "Screen width in density-independent pixels. Under 600 dp is a phone layout, 600 dp and up is tablet-like."))
        out.add(row("Refresh rate", "%.0f Hz".format(d.refreshRate), "How many times per second the screen redraws right now."))
        val modes = d.supportedModes.map { "%.0f".format(it.refreshRate) }.distinct().joinToString(", ")
        out.add(row("Supported rates", "$modes Hz", "Every refresh rate the panel can switch between. Adaptive displays move between them to save power."))
        return out
    }

    // ---------- Memory ----------

    fun memory(c: Context): List<Row> {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val info = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { l ->
                val v = l.substringAfter(':').trim().split(' ')[0].toLongOrNull()
                if (v != null) info[l.substringBefore(':')] = v * 1024L
            }
        } catch (e: Exception) { }
        val out = ArrayList<Row>()
        out.add(row("Total RAM", size(mi.totalMem),
            "RAM the kernel can use. A phone sold as 3 GB shows less because the rest is reserved for the GPU, modem and firmware."))
        out.add(row("Available", size(mi.availMem) + if (mi.lowMemory) " (LOW)" else "",
            "Memory free plus memory Android can reclaim from cached apps right now."))
        out.add(row("Low-memory threshold", size(mi.threshold),
            "Below this the system starts killing background apps."))
        info["Cached"]?.let { out.add(row("Cached", size(it), "File data kept in RAM for speed. Android drops it instantly when apps need space.")) }
        info["Buffers"]?.let { out.add(row("Buffers", size(it), "Kernel disk-block buffers.")) }
        val st = info["SwapTotal"] ?: 0L
        out.add(row("Swap (zRAM)", if (st > 0) size((info["SwapFree"] ?: 0L)) + " free of " + size(st) else "none",
            "Compressed RAM used as swap. It lets a small-RAM phone keep more apps alive at the cost of some CPU."))
        out.add(row("App heap limit", am.memoryClass.toString() + " MB (large: " + am.largeMemoryClass + " MB)",
            "How much memory one normal app may use. Apps that request a large heap get the bigger number."))
        out.add(row("Low-RAM device", if (am.isLowRamDevice) "yes" else "no",
            "Yes means the ROM runs in Android Go style with trimmed features to save memory."))
        return out
    }

    // ---------- Storage ----------

    private fun stat(f: File): Pair<Long, Long>? = try {
        val s = StatFs(f.path)
        Pair(s.blockCountLong * s.blockSizeLong, s.availableBlocksLong * s.blockSizeLong)
    } catch (e: Exception) { null }

    fun storage(c: Context): List<Row> {
        val out = ArrayList<Row>()
        stat(Environment.getDataDirectory())?.let {
            out.add(row("Internal (/data)", size(it.second) + " free of " + size(it.first),
                "Where apps and their data live. Total is the user-visible partition, so it is less than the advertised size."))
        }
        stat(Environment.getExternalStorageDirectory())?.let {
            out.add(row("Shared storage", size(it.second) + " free of " + size(it.first),
                "Photos, downloads and other files you can see in a file manager. Usually the same pool as /data."))
        }
        stat(File("/system"))?.let {
            out.add(row("System partition", size(it.first), "Read-only Android system image. Size grows with the ROM and preinstalled apps."))
        }
        val dirs = c.getExternalFilesDirs(null).filterNotNull()
        for (i in 1 until dirs.size) {
            stat(dirs[i])?.let {
                out.add(row("Extra volume $i", size(it.second) + " free of " + size(it.first),
                    "A removable SD card or other secondary volume."))
            }
        }
        if (out.isEmpty()) out.add(row("Storage", null, "Could not read storage statistics."))
        return out
    }

    // ---------- Battery ----------

    private fun statusName(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        else -> "Unknown"
    }

    private fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Unspecified failure"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        else -> "Unknown"
    }

    fun batteryTempC(c: Context): Double? {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10.0
    }

    fun battery(c: Context): List<Row> {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return listOf(row("Battery", null, "Android did not report battery data."))
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val src = when {
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC charger"
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Wireless"
            else -> "On battery"
        }
        val out = ArrayList<Row>()
        out.add(row("Level", if (level >= 0) (level * 100 / scale).toString() + " %" else null, "Charge percentage as the system reports it."))
        out.add(row("Status", statusName(i.getIntExtra(BatteryManager.EXTRA_STATUS, 1)), "Charging state. Not charging means plugged in but the charger is paused, e.g. to limit heat."))
        out.add(row("Power source", src, "What the phone is plugged into."))
        out.add(row("Health", healthName(i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1)), "Coarse health flag from the charger chip. It does not measure wear."))
        batteryTempC(c)?.let { out.add(row("Temperature", Prefs.t(c, it), "Battery pack temperature. Often the only thermal sensor an app is allowed to read.")) }
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        if (mv > 0) out.add(row("Voltage", "$mv mV", "Battery voltage. A Li-ion cell sits near 3700 mV and reaches about 4350 mV when full."))
        out.add(row("Technology", i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY), "Cell chemistry, usually Li-ion or Li-poly."))
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (cur != Int.MIN_VALUE && cur != 0) {
            val ma = if (Math.abs(cur) < 20000) cur else cur / 1000
            out.add(row("Current now", "$ma mA", "Instantaneous current. Some phones report the sign backwards and a few report mA instead of µA, so this is a best guess."))
        }
        val cc = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (cc > 0) out.add(row("Charge left", (cc / 1000).toString() + " mAh", "Remaining charge in the cell, when the phone exposes it."))
        return out
    }

    // ---------- Thermal ----------

    private fun zoneMeaning(t: String): String {
        val s = t.lowercase()
        return when {
            s.contains("cpu") || s.contains("tscpu") -> "A temperature sensor on a CPU core or cluster."
            s.contains("gpu") -> "A temperature sensor near the GPU."
            s.contains("batt") || s.contains("bat") -> "The battery pack sensor."
            s.contains("pmic") || s.contains("pmu") || s.contains("pm8") -> "Power-management chip, the part that regulates voltages."
            s.contains("modem") || s.contains("mdm") || s.contains("pa") -> "Modem or radio amplifier sensor."
            s.contains("skin") || s.contains("quiet") || s.contains("xo") || s.contains("board") -> "Board or case-surface estimate used to decide when to throttle."
            s.contains("soc") -> "Whole-chip (SoC) temperature."
            else -> "A vendor-named sensor with no standard meaning."
        }
    }

    private fun statusLabel(n: Int) = when (n) {
        0 -> "None"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"
        4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown"; else -> "Unknown"
    }

    class Zone(val name: String, val node: String, val raw: Long, val deg: Double)

    fun zones(): List<Zone> {
        val out = ArrayList<Zone>()
        val dirs = (File("/sys/class/thermal").listFiles() ?: emptyArray<File>())
            .filter { it.name.startsWith("thermal_zone") }
            .sortedBy { it.name.removePrefix("thermal_zone").toIntOrNull() ?: 0 }
        for (z in dirs) {
            val type = try { File(z, "type").readText().trim() } catch (e: Exception) { continue }
            val raw = try { File(z, "temp").readText().trim().toLong() } catch (e: Exception) { continue }
            val a = Math.abs(raw)
            val deg = if (a >= 1000) raw / 1000.0 else if (a >= 150) raw / 10.0 else raw.toDouble()
            if (deg >= -40.0 && deg <= 150.0) out.add(Zone(type, z.name, raw, deg))
        }
        return out
    }

    fun thermal(c: Context): List<Row> {
        val out = ArrayList<Row>()
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            out.add(row("Throttle status", statusLabel(pm.currentThermalStatus),
                "Android's own heat verdict. None is normal; Light and up means the system is already slowing things down."))
        }
        val z = zones()
        for (x in z) out.add(row(x.name, Prefs.t(c, x.deg), zoneMeaning(x.name) + " Raw value " + x.raw + " (" + x.node + ")."))
        if (z.isEmpty()) {
            batteryTempC(c)?.let { out.add(row("Battery temperature", Prefs.t(c, it), "Battery pack sensor. This phone exposes no other thermal sensors to apps.")) }
        }
        return out
    }
}
