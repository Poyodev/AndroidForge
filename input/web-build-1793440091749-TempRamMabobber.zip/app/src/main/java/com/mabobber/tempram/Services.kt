package com.mabobber.tempram

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

// Everything in this file runs in the small ":bg" process (see manifest): no Compose, no UI classes.

fun notifTexts(cfg: Config, s: Snap): Pair<String, String?> {
    val pct = s.used * 100 / s.total
    val head = buildList {
        if (cfg.notifTemp && s.temp != null) add(cfg.t(s.temp))
        if (cfg.notifRam) add("RAM $pct% (${gb(s.used)})")
    }.joinToString(" · ").ifEmpty { "Monitoring" }
    val big = if (!cfg.notifNodes) null else buildString {
        val all = channels(s, cfg.homeGroup, cfg.aggMax)
        (if (cfg.homeGroup != 0 || cfg.nodesAll) all else all.filter { isKeyNode(it.first) }).forEach {
            append(it.first).append("  ").append(cfg.t(it.second)).append('\n')
        }
        if (cfg.notifRam) append("RAM free ").append(gb(s.avail))
    }
    return head to big
}

class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Prefs.init(this)
        val act = i?.action
        if (act == "stop" || act == "stopall") {          // swipe-away / app Stop = stop logging; notification Stop button = stop everything
            Prefs.update { it.copy(always = false) }
            scope.coroutineContext.cancelChildren()
            if (act == "stopall") {
                stopService(Intent(this, OverlayService::class.java))
                stopService(Intent(this, FpsService::class.java))
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1)   // also clears a stale notification
            stopForeground(true); stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("mon", "Monitoring", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, MonitorService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val stopAll = PendingIntent.getService(this, 3, Intent(this, MonitorService::class.java).setAction("stopall"), PendingIntent.FLAG_IMMUTABLE)
        // launch intent by package name: avoids loading any UI class into this small background process
        val open = PendingIntent.getActivity(this, 0, packageManager.getLaunchIntentForPackage(packageName) ?: Intent(), PendingIntent.FLAG_IMMUTABLE)
        fun note(text: String, big: String? = null): Notification {
            val b = NotificationCompat.Builder(this, "mon").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Temperature and RAM mabobber").setContentText(text)
                .setOngoing(false).setOnlyAlertOnce(true)          // not "ongoing" so Android 14+ lets you swipe it away
                .setContentIntent(open).setDeleteIntent(stop)
                .setCategory(NotificationCompat.CATEGORY_SERVICE).setShowWhen(false)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopAll)
            if (big != null) b.setStyle(NotificationCompat.BigTextStyle().bigText(big))
            return b.build()
        }
        try {   // Android 12+ can refuse a foreground start from the background; never crash on it
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, note("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, note("Starting…"))
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        scope.coroutineContext.cancelChildren()
        scope.launch {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            var winMax = -1f; var winPkg = ""; var lastRec = 0L; var lastText = ""
            History.prune(this@MonitorService)
            while (isActive) {
                Prefs.reloadIfChanged()
                val on = pm.isInteractive
                Monitor.sample(this@MonitorService, 900)
                val s = Monitor.snap.value; val cfg = Prefs.cfg.value
                val pkg = if (on) Fg.current(this@MonitorService) else ""
                if (s?.temp != null) {
                    if (on) {   // no notification work while the screen is off
                        val (head, big) = notifTexts(cfg, s)
                        val key = head + big
                        if (key != lastText) { lastText = key; nm.notify(1, note(head, big)) }
                    }
                    if (s.temp > winMax) { winMax = s.temp; winPkg = pkg }
                    val now = System.currentTimeMillis()
                    if (now - lastRec >= cfg.histInterval * 1000L) {
                        History.append(this@MonitorService, now, winMax, s.used * 100f / s.total, winPkg)
                        lastRec = now; winMax = -1f; winPkg = ""
                    }
                }
                delay(if (on) cfg.intervalSec * 1000L else maxOf(cfg.intervalSec * 3000L, 10_000L))
            }
        }
        return START_STICKY          // survives "clear all" in recents; restarted if the system kills it
    }
    override fun onDestroy() { scope.cancel() }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Prefs.init(c)
        if (Prefs.cfg.value.always) ContextCompat.startForegroundService(c, Intent(c, MonitorService::class.java))
    }
}

/** Floating always-on-top monitor window (works over games, unlike a normal PiP activity). */
class OverlayService : Service() {
    private var view: OverlayView? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Prefs.init(this)
        if (view != null) return START_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 200 }
        lateinit var v: OverlayView
        v = OverlayView(this, { dx, dy -> lp.x += dx.toInt(); lp.y += dy.toInt(); wm.updateViewLayout(v, lp) }, { stopSelf() })
        wm.addView(v, lp); view = v
        return START_STICKY
    }
    override fun onDestroy() {
        view?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        view = null
    }
}

/** Live FPS without ADB or root: counts how often the screen content updates through a one-time screen-capture grant. */
object Fps {
    @Volatile var fps = 0f
    @Volatile var at = 0L              // elapsedRealtime of the last measurement; stale = nothing is being drawn
    @Volatile var running = false
}

class FpsService : Service() {
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var frames = 0
    private var t0 = 0L
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("mon", "Monitoring", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, FpsService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "mon").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("FPS counter running").setContentText("Counting screen updates for the floating window")
            .setOngoing(false).addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(2, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        @Suppress("DEPRECATION") val data: Intent? = i?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val th = HandlerThread("fps").also { it.start() }; thread = th
            val hd = Handler(th.looper)
            val mp = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(i!!.getIntExtra("code", 0), data)
            mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, hd)
            val r = ImageReader.newInstance(64, 128, PixelFormat.RGBA_8888, 2)      // tiny: we only count frames, never read pixels
            r.setOnImageAvailableListener({ rd -> rd.acquireLatestImage()?.close(); count() }, hd)
            vd = mp.createVirtualDisplay("fps", 64, 128, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, hd)
            proj = mp; reader = r; t0 = SystemClock.elapsedRealtime(); Fps.running = true
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun count() {
        frames++
        val now = SystemClock.elapsedRealtime()
        if (now - t0 >= 1000) { Fps.fps = frames * 1000f / (now - t0); Fps.at = now; frames = 0; t0 = now }
    }

    override fun onDestroy() {
        Fps.running = false; Fps.fps = 0f
        vd?.release(); reader?.close(); proj?.stop(); thread?.quitSafely()
    }
}
