@file:OptIn(ExperimentalMaterial3Api::class)
package com.mabobber.tempram

import android.Manifest
import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.widget.Toast
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

object UiState { var visible by mutableStateOf(false) }

class MainActivity : ComponentActivity() {
    override fun onStart() {
        super.onStart(); UiState.visible = true
        Prefs.init(this); Prefs.reloadIfChanged()
        if (Prefs.cfg.value.notifOnOpen) startMonitor(this)      // "instantly display when app is opened"
    }
    override fun onStop() { super.onStop(); UiState.visible = false }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF7FD6F5), background = Color(0xFF062F41), surface = Color(0xFF062F41))
        else -> lightColorScheme(primary = Color(0xFF00658A))
    }
    MaterialTheme(colorScheme = cs, content = content)
}

fun Config.tempColor(c: Float) = Color(tempArgb(c))
fun Config.ramColor(pct: Float) = Color(ramArgb(pct))
fun startMonitor(c: Context) = androidx.core.content.ContextCompat.startForegroundService(c, Intent(c, MonitorService::class.java))

@Composable
fun Root() {
    val ctx = LocalContext.current
    val cfg by Prefs.cfg.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableIntStateOf(0) }          // 0 main, 1 settings, 2 about
    val visible = UiState.visible
    LaunchedEffect(cfg.intervalSec, visible) {
        if (!visible) return@LaunchedEffect                   // nothing runs while the app is hidden
        while (true) { Prefs.reloadIfChanged(); withContext(Dispatchers.IO) { Monitor.sample(ctx, 900) }; delay(cfg.intervalSec * 1000L) }
    }
    val notif = rememberLauncherForActivityResult(RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    BackHandler(screen != 0) { screen = if (screen == 2) 1 else 0 }
    val sb = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(sb.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text(when (screen) { 0 -> "Temp & RAM mabobber"; 1 -> "Settings"; else -> "About" }) },
                navigationIcon = { if (screen != 0) IconButton({ screen = if (screen == 2) 1 else 0 }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
                actions = { if (screen == 0) IconButton({ screen = 1 }) { Icon(Icons.Rounded.Settings, "Settings") } },
                scrollBehavior = sb
            )
        },
        bottomBar = {
            if (screen == 0) NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Rounded.Home, null) }, label = { Text("Monitor") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Rounded.DateRange, null) }, label = { Text("Wellbeing") })
            }
        }
    ) { pad ->
        when {
            screen == 1 -> SettingsScreen(cfg, pad) { screen = 2 }
            screen == 2 -> AboutScreen(pad)
            tab == 0 -> Dashboard(cfg, pad)
            else -> WellbeingScreen(cfg, pad)
        }
    }
}

@Composable
fun Dashboard(cfg: Config, pad: PaddingValues) {
    val ctx = LocalContext.current
    val snapState by Monitor.snap.collectAsState()
    val s = snapState
    var week by remember { mutableStateOf(emptyList<Pair<String, Float?>>()) }
    LaunchedEffect(UiState.visible) { if (!UiState.visible) return@LaunchedEffect; while (true) { week = withContext(Dispatchers.IO) { History.weekPeaks(ctx) }; delay(60_000) } }
    Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (s == null) { CircularProgressIndicator(); return@Column }
        if (s.onlyBattery) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text("Sorry! This phone only exposes the battery temperature sensor to apps, so this reading might be inaccurate. It's not you, it's your phone's manufacturer.", Modifier.padding(16.dp))
        }
        if (cfg.showTemp && s.temp != null) {
            val h = cfg.heat(s.temp)
            Card(shape = RoundedCornerShape(36.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally), Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(progress = { (s.temp / 80f).coerceIn(0f, 1f) }, modifier = Modifier.size(150.dp), strokeWidth = 14.dp, color = cfg.tempColor(s.temp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(cfg.t(s.temp), style = MaterialTheme.typography.headlineLarge, color = cfg.tempColor(s.temp))
                            Text(h.label, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                    if (cfg.showSoc) SocPanel(Modifier.weight(1f))
                    }
                    if (cfg.showSoc) SocNotice()
                    if (cfg.showQuote) Text(remember(h) { h.quotes.random() }, Modifier.padding(top = 16.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        if (cfg.showRam) Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                val v = if (cfg.ramUsed) s.used else s.avail
                Text("RAM ${if (cfg.ramUsed) "used" else "free"}", style = MaterialTheme.typography.titleMedium)
                Text("${gb(v)} / ${gb(s.total)}", style = MaterialTheme.typography.headlineSmall)
                LinearProgressIndicator(progress = { v.toFloat() / s.total }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), color = cfg.ramColor(s.used * 100f / s.total))
            }
        }
        if (cfg.showNodes) {
            val all = channels(s, cfg.homeGroup, cfg.aggMax)
            val shown = if (cfg.homeGroup != 0 || cfg.nodesAll) all else all.filter { isKeyNode(it.first) }
            Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(when { cfg.homeGroup == 1 -> "CPU / GPU totals"; cfg.homeGroup == 2 -> "Core clusters"; cfg.nodesAll -> "All sensor nodes (${shown.size})"; else -> "SoC, PMU & battery" }, style = MaterialTheme.typography.titleMedium)
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        shown.forEach { (n, c) -> Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(n); Text(cfg.t(c), color = cfg.tempColor(c)) } }
                        if (shown.isEmpty()) Text("No thermal nodes readable on this device.")
                    }
                }
            }
        }
        WeekCard(cfg, week)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                if (!Settings.canDrawOverlays(ctx)) ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                else ctx.startService(Intent(ctx, OverlayService::class.java))
            }, Modifier.weight(1f)) { Text("Floating window") }
            FilledTonalButton({
                ctx.stopService(Intent(ctx, OverlayService::class.java))
            }, Modifier.weight(1f)) { Text("Close it") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ startMonitor(ctx) }, Modifier.weight(1f)) { Text("Notification now") }
            FilledTonalButton({ ctx.startService(Intent(ctx, MonitorService::class.java).setAction("stop")) }, Modifier.weight(1f)) { Text("Stop it") }
        }
    }
}

@Composable fun Toggle(label: String, on: Boolean, f: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text(label); Switch(on, f) }

@Composable fun SliderRow(label: String, v: Float, r: ClosedFloatingPointRange<Float>, f: (Float) -> Unit) =
    Column { Text(label); Slider(v, f, valueRange = r) }

@Composable fun Choice(opts: List<String>, sel: Int, on: (Int) -> Unit) = SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
    opts.forEachIndexed { i, o -> SegmentedButton(sel == i, { on(i) }, SegmentedButtonDefaults.itemShape(i, opts.size)) { Text(o) } }
}

@Composable fun Section(title: String, content: @Composable ColumnScope.() -> Unit) =
    Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium); content()
        }
    }

@Composable
fun SettingsScreen(cfg: Config, pad: PaddingValues, onAbout: () -> Unit) {
    val ctx = LocalContext.current
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/xml")) { uri ->
        if (uri != null) {
            val ok = try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(Prefs.toXml().toByteArray()) } != null } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) "Settings exported" else "Export failed", Toast.LENGTH_SHORT).show()
        }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val ok = try { ctx.contentResolver.openInputStream(uri)?.use { Prefs.importXml(it) } ?: false } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) "Settings imported" else "Not a valid settings file", Toast.LENGTH_SHORT).show()
        }
    }
    fun set(f: (Config) -> Config) = Prefs.update(f)
    val proj = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val d = res.data
        if (res.resultCode == Activity.RESULT_OK && d != null)
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, FpsService::class.java).putExtra("code", res.resultCode).putExtra("data", d))
        else { Prefs.update { it.copy(fpsMode = 0) }; Toast.makeText(ctx, "FPS needs the screen-capture permission", Toast.LENGTH_SHORT).show() }
    }
    Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("Dashboard") {
            Toggle("Temperature", cfg.showTemp) { v -> set { it.copy(showTemp = v) } }
            Toggle("RAM", cfg.showRam) { v -> set { it.copy(showRam = v) } }
            Toggle("Funny insults", cfg.showQuote) { v -> set { it.copy(showQuote = v) } }
            Toggle("Sensor node list", cfg.showNodes) { v -> set { it.copy(showNodes = v) } }
            Toggle("Show ALL nodes (off = SoC, PMU, battery only)", cfg.nodesAll) { v -> set { it.copy(nodesAll = v) } }
            Toggle("SoC & Android info (downloads logos once)", cfg.showSoc) { v -> set { it.copy(showSoc = v) } }
            Choice(listOf("RAM used", "RAM free"), if (cfg.ramUsed) 0 else 1) { i -> set { it.copy(ramUsed = i == 0) } }
            Choice(listOf("°C", "°F"), if (cfg.fahrenheit) 1 else 0) { i -> set { it.copy(fahrenheit = i == 1) } }
        }
        Section("Temperature colours & ratings") {
            val snapNow by Monitor.snap.collectAsState()
            var open by remember { mutableStateOf(false) }
            Box {
                OutlinedButton({ open = true }) { Text("Main sensor: ${cfg.mainNode.ifEmpty { "Auto" }}") }
                DropdownMenu(open, { open = false }) {
                    DropdownMenuItem({ Text("Auto") }, { set { it.copy(mainNode = "") }; open = false })
                    snapNow?.nodes?.forEach { (n, _) -> DropdownMenuItem({ Text(n) }, { set { it.copy(mainNode = n) }; open = false }) }
                }
            }
            SliderRow("Green below ${cfg.t(cfg.warmC)}", cfg.warmC, 25f..55f) { v -> set { it.copy(warmC = v.coerceAtMost(it.hotC - 1)) } }
            SliderRow("Red from ${cfg.t(cfg.hotC)} (yellow in between)", cfg.hotC, 35f..65f) { v -> set { it.copy(hotC = v.coerceAtLeast(it.warmC + 1)) } }
            SliderRow("Cold insult up to ${cfg.t(cfg.coldC)}", cfg.coldC, 20f..45f) { v -> set { it.copy(coldC = v.coerceAtMost(it.hotC - 1)) } }
            SliderRow("RAM red from ${cfg.ramRed}% used", cfg.ramRed.toFloat(), 50f..95f) { v -> set { it.copy(ramRed = v.roundToInt()) } }
            SliderRow("Dashboard refresh every ${cfg.intervalSec}s", cfg.intervalSec.toFloat(), 1f..10f) { v -> set { it.copy(intervalSec = v.roundToInt()) } }
        }
        Section("Sensor grouping (CPU / GPU / cores)") {
            Text("Home screen")
            Choice(listOf("Raw nodes", "CPU / GPU totals", "Core clusters"), cfg.homeGroup) { i -> set { it.copy(homeGroup = i) } }
            Text("Floating window")
            Choice(listOf("Raw nodes", "CPU / GPU totals", "Core clusters"), cfg.ovGroup) { i -> set { it.copy(ovGroup = i) } }
            Toggle("Totals use the hottest sensor (off = average)", cfg.aggMax) { v -> set { it.copy(aggMax = v) } }
            Text("Core clusters gives big / mid / little totals (for example 4 big + 4 little). Groups the phone has no sensors for are skipped.", style = MaterialTheme.typography.bodySmall)
        }
        Section("FPS counter (floating window only)") {
            Text("Source")
            Choice(listOf("Screen capture", "Display vsync"), cfg.fpsSource) { i ->
                set { it.copy(fpsSource = i) }
                if (i == 1) ctx.startService(Intent(ctx, FpsService::class.java).setAction("stop"))
                else if (cfg.fpsMode > 0) proj.launch((ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
            }
            Text("Show")
            Choice(listOf("Off", "Graph", "Numbers"), cfg.fpsMode) { i ->
                set { it.copy(fpsMode = i) }
                if (i == 0) ctx.startService(Intent(ctx, FpsService::class.java).setAction("stop"))
                else if (cfg.fpsSource == 0) proj.launch((ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
            }
            Text("FPS line colour")
            ColorPick(cfg.lineFps) { c -> set { it.copy(lineFps = c) } }
            Text("Screen capture: counts real screen updates through a one-time capture permission (a cast icon shows). A static screen reads near 0 FPS.\nDisplay vsync (the method in the AndroidForge app): no permission, but it follows the screen's refresh rate rather than what a game really renders.", style = MaterialTheme.typography.bodySmall)
        }
        Section("Floating window (shows over games)") {
            Toggle("Temperature", cfg.ovTemp) { v -> set { it.copy(ovTemp = v) } }
            Toggle("RAM", cfg.ovRam) { v -> set { it.copy(ovRam = v) } }
            Toggle("Funny insults", cfg.ovQuote) { v -> set { it.copy(ovQuote = v) } }
            Text("Window mode")
            Choice(listOf("Normal", "Graph only"), if (cfg.ovGraphOnly) 1 else 0) { i -> set { it.copy(ovGraphOnly = i == 1) } }
            if (cfg.ovGraphOnly) {
                Text("Temperature line colour")
                ColorPick(cfg.lineTemp) { c -> set { it.copy(lineTemp = c) } }
                Text("RAM line colour")
                ColorPick(cfg.lineRam) { c -> set { it.copy(lineRam = c) } }
            }
            Text("Window layout")
            Choice(listOf("Vertical", "Horizontal"), if (cfg.ovHorizontal) 1 else 0) { i -> set { it.copy(ovHorizontal = i == 1) } }
            val live by Monitor.snap.collectAsState()
            val chosen = if (cfg.ovNodes.isEmpty()) emptyList<String>() else cfg.ovNodes.split("|")
            Text("Sensors in the window")
            Text("RAM on: 1-2 nodes get graphs, 3+ become a scrolling list. RAM off: up to 3 nodes get graphs.", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Auto (main temperature)")
                Checkbox(chosen.isEmpty(), { _ -> set { it.copy(ovNodes = "") } })
            }
            Column(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                val names = (live?.nodes?.map { it.first } ?: emptyList()) + (if (live?.battery != null) listOf(BATT) else emptyList())
                names.forEach { n ->
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text(n, Modifier.weight(1f), maxLines = 1)
                        Checkbox(n in chosen, { on -> set { c -> c.copy(ovNodes = (if (on) chosen + n else chosen - n).joinToString("|").replace(",", "")) } })
                    }
                }
            }
            Text("Temperature style")
            Choice(listOf("Bar", "Graph"), if (cfg.ovTempGraph) 1 else 0) { i -> set { it.copy(ovTempGraph = i == 1) } }
            Text("RAM style")
            Choice(listOf("Bar", "Graph"), if (cfg.ovRamGraph) 1 else 0) { i -> set { it.copy(ovRamGraph = i == 1) } }
            SliderRow("Update every ${cfg.ovInterval}s (graph keeps last 40 updates)", cfg.ovInterval.toFloat(), 1f..10f) { v -> set { it.copy(ovInterval = v.roundToInt()) } }
            SliderRow("Size ${(cfg.ovScale * 100).roundToInt()}% (or drag its corner label)", cfg.ovScale, 0.6f..2f) { v -> set { it.copy(ovScale = v) } }
            SliderRow("Opacity ${(cfg.ovAlpha * 100).roundToInt()}%", cfg.ovAlpha, 0.3f..1f) { v -> set { it.copy(ovAlpha = v) } }
        }
        Section("Notification") {
            Toggle("Show temperature", cfg.notifTemp) { v -> set { it.copy(notifTemp = v) } }
            Toggle("Show RAM", cfg.notifRam) { v -> set { it.copy(notifRam = v) } }
            Toggle("Expanded view lists sensor nodes", cfg.notifNodes) { v -> set { it.copy(notifNodes = v) } }
            Toggle("Show the monitor notification as soon as the app opens", cfg.notifOnOpen) { v -> set { it.copy(notifOnOpen = v) } }
            Text("Needs background monitoring on. Pull the notification down to expand it.", style = MaterialTheme.typography.bodySmall)
        }
        Section("History") {
            SliderRow("Record every ${cfg.histInterval}s (keeps the peak of each interval)", cfg.histInterval.toFloat(), 30f..300f) { v -> set { it.copy(histInterval = ((v / 30f).roundToInt().coerceAtLeast(1)) * 30) } }
            SliderRow("Hot-app ranking changes every ${cfg.rankMinutes} min", cfg.rankMinutes.toFloat(), 1f..60f) { v -> set { it.copy(rankMinutes = v.roundToInt().coerceIn(1, 60)) } }
            Text("History records only while 'Keep monitoring in background' is on. Days are kept for 30 days.", style = MaterialTheme.typography.bodySmall)
            FilledTonalButton({ ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Usage access (for app ranking)") }
            OutlinedButton({ History.clear(ctx) }) { Text("Clear history") }
        }
        Section("Monitor at all times") {
            Toggle("Keep monitoring in background", cfg.always) { on ->
                set { it.copy(always = on) }
                if (on) startMonitor(ctx) else ctx.stopService(Intent(ctx, MonitorService::class.java))
            }
            Text("Custom Android skins and stock battery managers kill background apps. Set this app to Unrestricted / No restrictions and allow auto-start, or monitoring will stop.", style = MaterialTheme.typography.bodySmall)
            Button({ ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))) }) { Text("Unrestrict battery") }
            FilledTonalButton({ ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }) { Text("App settings (skin battery killer)") }
        }
        Section("Backup") {
            Text("Export or import every setting as an XML file.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ exp.launch("mabobber-settings.xml") }) { Text("Export XML") }
                FilledTonalButton({ imp.launch(arrayOf("text/xml", "application/xml", "*/*")) }) { Text("Import XML") }
            }
        }
        Card(onClick = onAbout, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("About & device specs", style = MaterialTheme.typography.titleMedium)
                Text("Build, credits, CPU, GPU, camera, screen, Android and kernel", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun WeekCard(cfg: Config, week: List<Pair<String, Float?>>) {
    val peak = week.mapNotNull { it.second }.maxOrNull()
    Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("This week's peak temperatures", style = MaterialTheme.typography.titleMedium)
            Text(if (peak == null) "No history yet. Turn on background monitoring in Settings." else "Hottest: ${cfg.t(peak)}", style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.fillMaxWidth().height(130.dp).padding(top = 8.dp), Arrangement.spacedBy(6.dp), Alignment.Bottom) {
                week.forEach { (day, p) ->
                    Column(Modifier.weight(1f), Arrangement.Bottom, Alignment.CenterHorizontally) {
                        Text(if (p == null) "-" else cfg.t(p), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        val h = if (p == null) 4f else 8f + 70f * ((p - 20f) / 40f).coerceIn(0f, 1f)
                        Box(Modifier.fillMaxWidth().height(h.dp).background(if (p == null) MaterialTheme.colorScheme.outlineVariant else cfg.tempColor(p), RoundedCornerShape(8.dp)))
                        Text(History.weekday(day), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun DayChart(dayStart: Long, ts: LongArray, v: FloatArray, n: Int, lo: Float, hi: Float, cfg: Config, isRam: Boolean, h: Int) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(h.dp)) {
        for (i in 0..4) { val x = size.width * i / 4; drawLine(grid, Offset(x, 0f), Offset(x, size.height)) }
        drawLine(grid, Offset(0f, size.height / 2), Offset(size.width, size.height / 2))
        fun px(t: Long) = size.width * ((t - dayStart) / 86_400_000f).coerceIn(0f, 1f)
        fun py(x: Float) = size.height * (1f - ((x - lo) / (hi - lo)).coerceIn(0f, 1f))
        val sw = 3.dp.toPx()
        for (i in 1 until n) {
            if (ts[i] - ts[i - 1] > 600_000) continue
            val c = if (isRam) cfg.ramColor(v[i]) else cfg.tempColor(v[i])
            drawLine(c, Offset(px(ts[i - 1]), py(v[i - 1])), Offset(px(ts[i]), py(v[i])), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun DaysChart(days: List<DayStat?>, cfg: Config) {
    val hi = maxOf(60f, days.maxOfOrNull { it?.max ?: 0f } ?: 60f)
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (days.size - 1)) / days.size
        days.forEachIndexed { i, d ->
            if (d != null) {
                val x = i * (bw + gap)
                val top = size.height * (1f - ((d.max - 20f) / (hi - 20f)).coerceIn(0.03f, 1f))
                drawRoundRect(cfg.tempColor(d.max), Offset(x, top), Size(bw, size.height - top), CornerRadius(bw / 4))
                val ya = size.height * (1f - ((d.avg - 20f) / (hi - 20f)).coerceIn(0f, 1f))
                drawLine(Color.White, Offset(x, ya), Offset(x + bw, ya), 2.dp.toPx())
            }
        }
    }
}

@Composable
fun TimeAxis() = Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
    listOf("00:00", "06:00", "12:00", "18:00", "24:00").forEach { Text(it, style = MaterialTheme.typography.labelSmall) }
}

@Composable
fun RowScope.Stat(label: String, value: String, color: Color, whenText: String) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.titleLarge, color = color)
        Text(whenText, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
fun SuspectCard(rank: Int, a: AppStat, cfg: Config) {
    val ctx = LocalContext.current
    val title = when (rank) { 1 -> "🔥 The one who fries your damn phone"; 2 -> "🥈 2nd hottest suspect"; else -> "🥉 3rd hottest suspect" }
    val container = if (rank == 1) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
    Card(colors = CardDefaults.cardColors(containerColor = container), shape = RoundedCornerShape(if (rank == 1) 32.dp else 24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(remember(a.pkg) { appLabel(ctx, a.pkg) }, style = if (rank == 1) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium)
            Text("Peak ${cfg.t(a.peak)} · avg ${cfg.t(a.avg)} · ~${a.minutes} min", color = cfg.tempColor(a.peak), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun WellbeingScreen(cfg: Config, pad: PaddingValues) {
    val ctx = LocalContext.current
    val today = History.dayKey(System.currentTimeMillis())
    var mode by remember { mutableIntStateOf(0) }
    var day by remember { mutableStateOf(today) }
    var series by remember { mutableStateOf<DaySeries?>(null) }
    var range by remember { mutableStateOf<Range?>(null) }
    var access by remember { mutableStateOf(hasUsageAccess(ctx)) }
    var apps by remember { mutableStateOf<List<AppStat>>(emptyList()) }
    var force by remember { mutableIntStateOf(0) }
    val visible = UiState.visible
    LaunchedEffect(mode, day, visible, cfg.rankMinutes, force) {
        if (!visible) return@LaunchedEffect
        var appsAt = 0L          // ranking only changes when this timer runs out
        while (true) {
            val keys = when (mode) { 0 -> listOf(day); 1 -> History.keys(7); else -> History.keys(30) }
            val (se, r) = withContext(Dispatchers.IO) { (if (mode == 0) History.series(ctx, day) else null) to History.range(ctx, keys, ctx.packageName) }
            series = se; range = r; access = hasUsageAccess(ctx)
            val now = SystemClock.elapsedRealtime()
            if (appsAt == 0L || now - appsAt >= cfg.rankMinutes * 60_000L) { apps = r.apps; appsAt = now }
            delay(if (mode == 0) 5000 else 30_000)
        }
    }
    Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!cfg.always) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("History only records while background monitoring is on.")
                Button({ Prefs.update { it.copy(always = true) }; startMonitor(ctx) }) { Text("Start recording") }
            }
        }
        if (!access) Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("To see which app was open when it got hot, allow Usage access for this app (same permission Digital Wellbeing uses).")
                Button({ ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Grant usage access") }
            }
        }
        Choice(listOf("Day", "Week", "Month"), mode) { mode = it }
        if (mode == 0) Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            TextButton({ day = History.shift(day, -1) }) { Text("◀") }
            Text(History.dayLabel(day) + if (day == today) " (today)" else "", style = MaterialTheme.typography.titleMedium)
            TextButton({ day = History.shift(day, 1) }, enabled = day < today) { Text("▶") }
        } else Text(if (mode == 1) "Last 7 days" else "Last 30 days", style = MaterialTheme.typography.titleMedium)
        val r = range
        if (r == null || r.peak < 0f) Text("No data recorded for this period yet.") else {
            Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(20.dp)) {
                    fun at(ts: Long) = if (mode == 0) History.clock(ts) else History.stamp(ts)
                    Stat("Average", cfg.t(r.avg), cfg.tempColor(r.avg), "${if (mode == 0) "day" else if (mode == 1) "week" else "month"} avg")
                    Stat("Peak hot", cfg.t(r.peak), cfg.tempColor(r.peak), at(r.peakTs))
                    Stat("Lowest cold", cfg.t(r.low), cfg.tempColor(r.low), at(r.lowTs))
                }
            }
            Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val se = series
                    if (mode == 0 && se != null && se.n > 0) {
                        val start = History.dayStart(day)
                        val lo = (r.low - 2f).coerceAtLeast(15f)
                        val hi = maxOf(r.peak + 2f, lo + 10f)
                        Text("Temperature today", style = MaterialTheme.typography.titleMedium)
                        Text("${cfg.t(hi)} top / ${cfg.t(lo)} bottom", style = MaterialTheme.typography.labelSmall)
                        DayChart(start, se.ts, se.t, se.n, lo, hi, cfg, false, 160)
                        TimeAxis()
                        Text("RAM used", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                        DayChart(start, se.ts, se.r, se.n, 0f, 100f, cfg, true, 90)
                        TimeAxis()
                    } else if (mode != 0) {
                        val ks = remember(mode) { History.keys(if (mode == 1) 7 else 30) }
                        Text("Daily peak (bar) and average (white line)", style = MaterialTheme.typography.titleMedium)
                        DaysChart(r.days, cfg)
                        if (mode == 1) Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { ks.forEach { Text(History.weekday(it), style = MaterialTheme.typography.labelSmall) } }
                        else Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(History.shortDay(ks.first()), style = MaterialTheme.typography.labelSmall); Text(History.shortDay(ks.last()), style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Ranking updates every ${cfg.rankMinutes} min", style = MaterialTheme.typography.labelMedium)
                TextButton({ force++ }) { Text("Refresh now") }
            }
            if (apps.isEmpty()) Text("No app data yet. Grant usage access and keep monitoring on.", style = MaterialTheme.typography.bodySmall)
            apps.take(3).forEachIndexed { i, a -> SuspectCard(i + 1, a, cfg) }
            if (apps.size > 3) Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("More suspects", style = MaterialTheme.typography.titleMedium)
                    apps.drop(3).take(12).forEachIndexed { i, a ->
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Text("${i + 4}. ${remember(a.pkg) { appLabel(ctx, a.pkg) }}", Modifier.weight(1f), maxLines = 1)
                            Column(horizontalAlignment = Alignment.End) {
                                Text(cfg.t(a.peak), color = cfg.tempColor(a.peak), style = MaterialTheme.typography.titleSmall)
                                Text("${a.minutes} min · avg ${cfg.t(a.avg)}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogoImg(b: ImageBitmap?, label: String) {
    if (b != null) Image(b, label, Modifier.size(26.dp))
    else Box(Modifier.size(26.dp).background(MaterialTheme.colorScheme.outlineVariant, CircleShape), contentAlignment = Alignment.Center) {
        Text(label.take(1), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun SocPanel(mod: Modifier) {
    val ctx = LocalContext.current
    val soc = remember { Soc.info }
    val and = remember { Soc.android }
    var socLogo by remember { mutableStateOf<ImageBitmap?>(null) }
    var andLogo by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(Unit) {
        val (a, b) = withContext(Dispatchers.IO) { Logos.get(ctx, soc.domain) to Logos.get(ctx, "android.com") }
        socLogo = a; andLogo = b
    }
    Column(mod, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LogoImg(socLogo, soc.maker)
            Text(soc.maker, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        }
        Text(soc.marketing.ifEmpty { soc.names.ifEmpty { "Marketing name unknown" } }, style = MaterialTheme.typography.titleMedium)
        Text("Codename: ${soc.model}", style = MaterialTheme.typography.bodySmall)
        Text("${soc.cores} cores" + if (soc.maxMHz > 0) " · up to %.2f GHz".format(soc.maxMHz / 1000f) else "", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LogoImg(andLogo, "Android")
            Text(and.title, style = MaterialTheme.typography.titleSmall)
        }
        Text(and.sub, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun SocNotice() {
    if (!Soc.info.flagged) return
    val ctx = LocalContext.current
    val link = MaterialTheme.colorScheme.primary
    val text = remember(link) {
        buildAnnotatedString {
            append("There might be a possibility that your SOC was part of a scandal ")
            pushStringAnnotation("URL", UL_URL)
            pushStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline))
            append("know more")
            pop(); pop()
        }
    }
    Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
        ClickableText(text, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onTertiaryContainer)) { off ->
            text.getStringAnnotations("URL", off, off).firstOrNull()?.let {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.item)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}

private val PALETTE = intArrayOf(0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(),
    0xFF00BCD4.toInt(), 0xFF2196F3.toInt(), 0xFF9C27B0.toInt(), 0xFFFFFFFF.toInt())

@Composable
fun ColorPick(cur: Int, on: (Int) -> Unit) = Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
    PALETTE.forEach { c ->
        Box(Modifier.size(30.dp).background(Color(c), CircleShape)
            .then(if (c == cur) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
            .clickable { on(c) })
    }
}

@Composable
fun AboutScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    var specs by remember { mutableStateOf<List<SpecSection>>(emptyList()) }
    LaunchedEffect(Unit) { specs = withContext(Dispatchers.IO) { Specs.read(ctx) } }
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.about_logo), "App logo", Modifier.size(128.dp).clip(RoundedCornerShape(32.dp)))
        Text("Temperature and RAM mabobber", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Text("Version 5.1 \"Teasing Tanuki R1\"", style = MaterialTheme.typography.titleMedium)
        Text("Built with Claude Sonnet 5.5 (Anthropic)")
        Text("Compiled by Symon Matthew (Haswell studios)")
        if (specs.isEmpty()) CircularProgressIndicator()
        specs.forEach { (title, rows) ->
            Card(shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    rows.forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                            Text(k, Modifier.weight(0.4f), style = MaterialTheme.typography.labelMedium)
                            Text(v, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}
