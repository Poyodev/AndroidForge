package com.mabobber.tempram

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.io.File

// Everything here runs in the small ":bg" process.

/** True while the logger loop is alive in this process. A fresh process (after a kill) starts with false. */
object Live { @Volatile var logging = false }

/** Tiny shared state file so the UI process can see what the logger is doing. */
object LogState {
    private fun f(c: Context) = File(c.applicationContext.filesDir, "state.txt")
    /** (logging expected, notification hidden) */
    fun read(c: Context): Pair<Boolean, Boolean> = try {
        val t = f(c).readText(); t.contains("exp=1") to t.contains("silent=1")
    } catch (e: Exception) { false to false }
    fun set(c: Context, exp: Boolean, silent: Boolean) {
        try { f(c).writeText("exp=" + (if (exp) 1 else 0) + "\nsilent=" + (if (silent) 1 else 0) + "\n") } catch (_: Exception) {}
    }
}

/** System alarm that outlives the process: if the logger vanished (killed by Android) it tells the user. */
object Watchdog {
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 9, Intent(c, WatchReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    fun arm(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 4 * 60_000L, pi(c))
    }
    fun cancel(c: Context) { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) }
}

class WatchReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!LogState.read(c).first) return                  // nobody expects logging any more
        if (Live.logging) { Watchdog.arm(c); return }      // still alive: check again later
        LogState.set(c, false, false)
        Alerts.post(c, "Logging stopped", "Android ended TARM's background logger.", resume = true)
        CenterNotice.show(c, "Temperature logging has stopped")
    }
}

object Alerts {
    private fun resumePI(c: Context): PendingIntent {
        val i = Intent(c, MonitorService::class.java)
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(c, 10, i, PendingIntent.FLAG_IMMUTABLE)
        else PendingIntent.getService(c, 10, i, PendingIntent.FLAG_IMMUTABLE)
    }
    /** Heads-up notification (pops over whatever is on screen). */
    fun post(c: Context, title: String, text: String, resume: Boolean = false) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("alert", "TARM alerts", NotificationManager.IMPORTANCE_HIGH))
        val b = NotificationCompat.Builder(c, "alert").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title).setContentText(text).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE).setAutoCancel(true)
        if (resume) b.addAction(0, "Resume logging", resumePI(c)) else b.setTimeoutAfter(15_000L)
        nm.notify(7, b.build())
    }
}

/** Centre-of-screen message card. Needs "display over other apps"; falls back to a toast. */
object CenterNotice {
    fun show(ctx: Context, msg: String, ms: Long = 6000L) {
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            try {
                if (!Settings.canDrawOverlays(app)) { Toast.makeText(app, msg, Toast.LENGTH_LONG).show(); return@post }
                val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val d = app.resources.displayMetrics.density
                val tv = TextView(app)
                tv.text = msg; tv.setTextColor(0xFFFFFFFF.toInt()); tv.textSize = 16f; tv.gravity = Gravity.CENTER
                tv.setPadding((22 * d).toInt(), (18 * d).toInt(), (22 * d).toInt(), (18 * d).toInt())
                tv.background = GradientDrawable().apply { setColor(0xF0263238.toInt()); cornerRadius = 28 * d }
                val lp = WindowManager.LayoutParams(
                    (app.resources.displayMetrics.widthPixels * 0.8f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.CENTER }
                fun close() { try { wm.removeView(tv) } catch (_: Exception) {} }
                tv.setOnClickListener { close() }
                wm.addView(tv, lp)
                tv.postDelayed({ close() }, ms)
            } catch (_: Exception) {}
        }
    }
}
