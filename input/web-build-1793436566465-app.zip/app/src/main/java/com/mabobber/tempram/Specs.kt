package com.mabobber.tempram

import android.app.ActivityManager
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import kotlin.math.sqrt

typealias SpecSection = Pair<String, List<Pair<String, String>>>

/** Phone spec sheet. Built once when the About screen opens and dropped when it closes. */
object Specs {
    private val PART = mapOf(
        "0xd03" to "Cortex-A53", "0xd04" to "Cortex-A35", "0xd05" to "Cortex-A55", "0xd07" to "Cortex-A57",
        "0xd08" to "Cortex-A72", "0xd09" to "Cortex-A73", "0xd0a" to "Cortex-A75", "0xd0b" to "Cortex-A76",
        "0xd0d" to "Cortex-A77", "0xd41" to "Cortex-A78", "0xd44" to "Cortex-X1", "0xd46" to "Cortex-A510",
        "0xd47" to "Cortex-A710", "0xd48" to "Cortex-X2", "0xd4d" to "Cortex-A715", "0xd4e" to "Cortex-X3",
    )

    fun read(ctx: Context): List<SpecSection> = listOf(
        "Device" to device(ctx), "CPU" to cpu(), "GPU" to gpu(ctx), "Camera" to camera(ctx),
        "Screen" to screen(ctx), "Android" to android(), "Kernel" to kernel(),
    )

    private fun device(ctx: Context): List<Pair<String, String>> {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return listOf("Model" to "${Build.MANUFACTURER} ${Build.MODEL}", "Device codename" to Build.DEVICE,
            "Product" to Build.PRODUCT, "RAM" to gb(mi.totalMem))
    }

    private fun cpu(): List<Pair<String, String>> {
        val si = Soc.info
        return listOf(
            "Brand" to si.maker, "Marketing name" to si.marketing.ifEmpty { si.names.ifEmpty { "unknown (not in the built-in list)" } },
            "Codename" to si.model, "Hardware id" to Build.HARDWARE,
            "Cores" to si.cores.toString() + " total",
            "Layout" to Soc.cpuSummary(si.maker == "Qualcomm"),
            "Max clock" to if (si.maxMHz > 0) "%.2f GHz".format(si.maxMHz / 1000f) else "unknown",
            "ABIs" to Build.SUPPORTED_ABIS.joinToString(),
        )
    }

    private fun gpu(ctx: Context): List<Pair<String, String>> {
        val rows = ArrayList<Pair<String, String>>()
        try {
            val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val v = IntArray(2); EGL14.eglInitialize(d, v, 0, v, 1)
            val cfg = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
            EGL14.eglChooseConfig(d, intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE), 0, cfg, 0, 1, n, 0)
            val c = EGL14.eglCreateContext(d, cfg[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            val s = EGL14.eglCreatePbufferSurface(d, cfg[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
            EGL14.eglMakeCurrent(d, s, s, c)
            rows += "Renderer" to (GLES20.glGetString(GLES20.GL_RENDERER) ?: "unknown")
            rows += "Vendor" to (GLES20.glGetString(GLES20.GL_VENDOR) ?: "unknown")
            rows += "Driver" to (GLES20.glGetString(GLES20.GL_VERSION) ?: "unknown")
            EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(d, s); EGL14.eglDestroyContext(d, c)
        } catch (e: Throwable) { rows += "Renderer" to "unavailable" }
        if (Build.VERSION.SDK_INT >= 24) {
            val ver = ctx.packageManager.systemAvailableFeatures.firstOrNull { it.name == "android.hardware.vulkan.version" }?.version
            rows += "Vulkan" to if (ver == null || ver == 0) "not supported" else "${ver shr 22}.${(ver shr 12) and 0x3ff}"
        }
        return rows
    }

    private fun camera(ctx: Context): List<Pair<String, String>> {
        val rows = ArrayList<Pair<String, String>>()
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in cm.cameraIdList.take(8)) {
                val ch = cm.getCameraCharacteristics(id)
                val face = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_FRONT -> "front"; CameraCharacteristics.LENS_FACING_BACK -> "back"; else -> "external"
                }
                val px = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
                val ap = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull()
                val fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                rows += "Camera $id ($face)" to buildList {
                    if (px != null) add("%.1f MP".format(px.width * px.height / 1e6))
                    if (ap != null) add("f/%.1f".format(ap))
                    if (fl != null) add("%.1f mm".format(fl))
                }.joinToString(" · ").ifEmpty { "no data" }
            }
        } catch (e: Exception) { rows += "Camera" to "not readable" }
        return rows.ifEmpty { listOf("Camera" to "none found") }
    }

    @Suppress("DEPRECATION")
    private fun screen(ctx: Context): List<Pair<String, String>> {
        val d = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        val m = DisplayMetrics(); d.getRealMetrics(m)
        val inch = sqrt((m.widthPixels / m.xdpi) * (m.widthPixels / m.xdpi) + (m.heightPixels / m.ydpi) * (m.heightPixels / m.ydpi))
        val hz = if (Build.VERSION.SDK_INT >= 23) d.supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted().joinToString(" / ") + " Hz"
        else "%.0f Hz".format(d.refreshRate)
        return listOf("Resolution" to "${m.widthPixels} × ${m.heightPixels}", "Size" to "%.1f inch".format(inch),
            "Density" to "${m.densityDpi} dpi (${"%.2f".format(m.density)}x)", "Refresh rate" to hz)
    }

    private fun android(): List<Pair<String, String>> = listOf(
        "Version" to Soc.android.title, "API / patch" to Soc.android.sub, "Build" to Build.DISPLAY,
        "Incremental" to Build.VERSION.INCREMENTAL, "Build id" to Build.ID,
    )

    /** Splits /proc/version into its parts (version, GKI branch, git commit, builder, compiler...). */
    private fun kernel(): List<Pair<String, String>> {
        val raw = try { File("/proc/version").readText().trim() } catch (e: Exception) { "Linux version " + (System.getProperty("os.version") ?: "unknown") }
        val rows = ArrayList<Pair<String, String>>()
        val ver = Regex("Linux version (\\S+)").find(raw)?.groupValues?.get(1) ?: System.getProperty("os.version") ?: "unknown"
        val m = Regex("^(\\d+)\\.(\\d+)\\.(\\d+)(.*)$").find(ver)
        if (m != null) {
            val (a, b, c, suffix) = m.destructured
            rows += "Kernel" to "Linux $a.$b.$c"
            rows += "Series / stable patch" to "$a.$b / $c"
            if (suffix.isNotEmpty()) rows += "Local version" to suffix
            Regex("-(android\\d+)-(\\d+)").find(suffix)?.let { rows += "GKI branch" to "${it.groupValues[1]}-$a.$b"; rows += "KMI generation" to it.groupValues[2] }
            Regex("-g([0-9a-f]{7,})").find(suffix)?.let { rows += "Git commit" to it.groupValues[1] }
            val flags = listOf("perf", "dirty", "debug", "rt").filter { "-$it" in suffix }
            if (flags.isNotEmpty() || suffix.endsWith("+")) rows += "Variant flags" to (flags + (if (suffix.endsWith("+")) listOf("modified (+)") else emptyList())).joinToString()
        } else rows += "Kernel" to ver
        Regex("\\(([^()@\\s]+@[^()\\s]+)\\)").find(raw)?.let { rows += "Built by" to it.groupValues[1] }
        Regex("(clang version [^,)]+|gcc version [^)]+)").find(raw)?.let { rows += "Compiler" to it.groupValues[1].trim() }
        Regex("#(\\d+)").find(raw)?.let { rows += "Build number" to "#" + it.groupValues[1] }
        val after = raw.substringAfter('#', "")
        Regex("\\b(SMP|PREEMPT_RT|PREEMPT)\\b").findAll(after).map { it.value }.distinct().joinToString(" ").takeIf { it.isNotEmpty() }?.let { rows += "Scheduler flags" to it }
        Regex("[A-Z][a-z]{2} [A-Z][a-z]{2} +\\d+ [\\d:]+ \\S+ \\d{4}").find(raw)?.let { rows += "Build date" to it.value }
        rows += "Architecture" to (System.getProperty("os.arch") ?: "unknown")
        return rows
    }
}
