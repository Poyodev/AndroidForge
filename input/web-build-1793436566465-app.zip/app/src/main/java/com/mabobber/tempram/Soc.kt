package com.mabobber.tempram

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

const val UL_URL = "https://benchmarks.ul.com/news/ul-delists-mediatek-powered-phones-with-suspect-benchmark-scores"

class SocInfo(val maker: String, val domain: String, val model: String, val names: String, val cores: Int, val maxMHz: Int, val flagged: Boolean, val marketing: String = "")
class CoreInfo(val impl: Int, val part: Int, val khz: Int)
class AndroidInfo(val title: String, val sub: String)

private class Chip(val code: String, val names: String, val flagged: Boolean)

/**
 * "Sports Mode" benchmark-scandal list. UL delisted PCMark scores for the Helio G90, G70, P95, P90, P65, P60, P20 and A22.
 * Dimensity 1000L is included because AnandTech found a Sports Mode whitelist on a Dimensity 1000L phone too.
 * Model codes are shared between sibling chips, so the wording stays "might".
 */
private val CHIPS = arrayOf(
    Chip("MT6785", "Helio G90 family", true),
    Chip("MT6769", "Helio G70 / G80 / G85 family", true),
    Chip("MT6768", "Helio P65 family", true),
    Chip("MT6779", "Helio P90 / P95", true),
    Chip("MT6771", "Helio P60 / P70 family", true),
    Chip("MT6757", "Helio P20 / P25 family", true),
    Chip("MT6761", "Helio A20 / A22 family", true),
    Chip("MT6885", "Dimensity 1000L", true),
    Chip("MT6765", "Helio P35 / G35 / G37 family", false),
    Chip("MT6835", "Helio G100 family", false),
    Chip("MT6877", "Dimensity 1080 / 7050 family", false),
    Chip("MT6762", "Helio P22 / G25 family", false),
)
/** Marketing names by model code. Best effort: codes are shared between sibling chips, so some entries list a family. */
private val MK = arrayOf(
    "MT6757", "Helio P20 / P25", "MT6797", "Helio X20 / X25", "MT6755", "Helio P10 / P15", "MT6761", "Helio A20 / A22",
    "MT6762", "Helio P22 / G25", "MT6765", "Helio P35 / G35 / G37", "MT6768", "Helio P65 family", "MT6769", "Helio G70 / G80 / G85",
    "MT6771", "Helio P60 / P70", "MT6779", "Helio P90 / P95", "MT6781", "Helio G96", "MT6785", "Helio G90 / G95", "MT6789", "Helio G99",
    "MT6835", "Helio G100 / Dimensity 6xxx family", "MT6833", "Dimensity 700", "MT6853", "Dimensity 720 / 800U", "MT6873", "Dimensity 800",
    "MT6877", "Dimensity 900 / 1080 / 7050", "MT6885", "Dimensity 1000L", "MT6889", "Dimensity 1000 / 1000+", "MT6891", "Dimensity 1100",
    "MT6893", "Dimensity 1200", "MT6895", "Dimensity 8100", "MT6983", "Dimensity 9000", "MT6985", "Dimensity 9200",
    "MT6989", "Dimensity 9300", "MT6991", "Dimensity 9400",
    "SM8750", "Snapdragon 8 Elite", "SM8650", "Snapdragon 8 Gen 3", "SM8635", "Snapdragon 8s Gen 3", "SM8550", "Snapdragon 8 Gen 2",
    "SM8475", "Snapdragon 8+ Gen 1", "SM8450", "Snapdragon 8 Gen 1", "SM8350", "Snapdragon 888", "SM8250", "Snapdragon 865 / 870",
    "SM8150", "Snapdragon 855", "SDM845", "Snapdragon 845", "MSM8998", "Snapdragon 835", "MSM8996", "Snapdragon 820 / 821",
    "SM7675", "Snapdragon 7+ Gen 3", "SM7550", "Snapdragon 7 Gen 3", "SM7475", "Snapdragon 7+ Gen 2", "SM7325", "Snapdragon 778G family",
    "SM7250", "Snapdragon 765G", "SM7150", "Snapdragon 730", "SDM710", "Snapdragon 710", "SM6375", "Snapdragon 695", "SM6350", "Snapdragon 690",
    "SM6150", "Snapdragon 675", "SM6125", "Snapdragon 665", "SM6115", "Snapdragon 662", "SM4350", "Snapdragon 480", "SDM660", "Snapdragon 660",
    "SDM636", "Snapdragon 636", "SDM450", "Snapdragon 450",
    "S5E9945", "Exynos 2400", "S5E9925", "Exynos 2200", "S5E9840", "Exynos 2100", "S5E8825", "Exynos 1280",
    "ZUMAPRO", "Google Tensor G4", "ZUMA", "Google Tensor G3", "GS201", "Google Tensor G2", "GS101", "Google Tensor",
)
private fun marketingOf(up: String): String? { var i = 0; while (i < MK.size) { if (MK[i] in up) return MK[i + 1]; i += 2 }; return null }

private val ARM_P = intArrayOf(0xd03, 0xd04, 0xd05, 0xd07, 0xd08, 0xd09, 0xd0a, 0xd0b, 0xd0d, 0xd41, 0xd44, 0xd46, 0xd47, 0xd48, 0xd4d, 0xd4e, 0xd80, 0xd81, 0xd82)
private val ARM_N = arrayOf("Cortex-A53", "Cortex-A35", "Cortex-A55", "Cortex-A57", "Cortex-A72", "Cortex-A73", "Cortex-A75", "Cortex-A76",
    "Cortex-A77", "Cortex-A78", "Cortex-X1", "Cortex-A510", "Cortex-A710", "Cortex-X2", "Cortex-A715", "Cortex-X3", "Cortex-A520", "Cortex-A720", "Cortex-X4")

private val FLAGGED_NAMES = arrayOf("helio g90", "helio g70", "helio p95", "helio p90", "helio p65", "helio p60", "helio p20", "helio a22", "dimensity 1000l")

object Soc {
    val info: SocInfo by lazy { read() }          // computed once
    val android: AndroidInfo by lazy { readAndroid() }

    private fun valid(s: String?) = !s.isNullOrBlank() && !s.equals("unknown", true)

    private fun read(): SocInfo {
        val parts = ArrayList<String>()
        var socModel: String? = null
        if (Build.VERSION.SDK_INT >= 31) { parts.add(Build.SOC_MANUFACTURER); parts.add(Build.SOC_MODEL); socModel = Build.SOC_MODEL }
        parts.add(Build.HARDWARE); parts.add(Build.BOARD)
        try {
            File("/proc/cpuinfo").bufferedReader().useLines { seq ->
                for (l in seq) if (l.startsWith("Hardware")) { parts.add(l.substringAfter(':').trim()); break }
            }
        } catch (_: Exception) {}
        val all = parts.filter { valid(it) }.joinToString(" ")
        val low = all.lowercase()
        val code = Regex("mt\\d{4}", RegexOption.IGNORE_CASE).find(all)?.value?.uppercase()
        val (maker, domain) = when {
            code != null || "mediatek" in low -> "MediaTek" to "mediatek.com"
            "qcom" in low || "qualcomm" in low || "snapdragon" in low || Regex("\\b(sm|sdm|msm|apq)\\d").containsMatchIn(low) -> "Qualcomm" to "qualcomm.com"
            "exynos" in low || "samsung" in low || "s5e" in low || "universal" in low -> "Samsung" to "samsung.com"
            "kirin" in low || "hisilicon" in low || "hi3" in low || "hi6" in low -> "HiSilicon" to "hisilicon.com"
            "unisoc" in low || "spreadtrum" in low || Regex("\\b(ums|sc|sp)\\d").containsMatchIn(low) -> "Unisoc" to "unisoc.com"
            "tensor" in low || Regex("\\bgs\\d{3}").containsMatchIn(low) || "zuma" in low -> "Google" to "google.com"
            valid(Build.MANUFACTURER) -> Build.MANUFACTURER.replaceFirstChar { it.uppercase() } to ""
            else -> "Unknown" to ""
        }
        val chip = CHIPS.firstOrNull { code != null && code.startsWith(it.code) }
        val model = (if (valid(socModel)) socModel!! else if (valid(Build.HARDWARE)) Build.HARDWARE else "unknown").uppercase()
        val flagged = chip?.flagged == true || FLAGGED_NAMES.any { it in low }
        val cores = Runtime.getRuntime().availableProcessors()
        var maxKhz = 0
        for (i in 0 until cores) {
            val k = try { File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toInt() } catch (e: Exception) { 0 }
            if (k > maxKhz) maxKhz = k
        }
        return SocInfo(maker, domain, model, chip?.names ?: "", cores, maxKhz / 1000, flagged, marketingOf(all.uppercase()) ?: "")
    }

    // ---------- CPU topology (read once, only when needed) ----------
    val cpus: List<CoreInfo> by lazy { readCpus() }
    private val freqs: List<Int> by lazy { cpus.map { it.khz }.filter { it > 0 }.distinct().sorted() }

    private fun readCpus(): List<CoreInfo> {
        val n = Runtime.getRuntime().availableProcessors()
        val impl = IntArray(n); val part = IntArray(n)
        try {
            File("/proc/cpuinfo").bufferedReader().useLines { seq ->
                var idx = -1
                for (l in seq) {
                    val v = l.substringAfter(':', "").trim()
                    when {
                        l.startsWith("processor") -> idx = v.toIntOrNull() ?: idx
                        l.startsWith("CPU implementer") && idx in 0 until n -> impl[idx] = v.removePrefix("0x").toInt(16)
                        l.startsWith("CPU part") && idx in 0 until n -> part[idx] = v.removePrefix("0x").toInt(16)
                    }
                }
            }
        } catch (_: Exception) {}
        return List(n) { i ->
            CoreInfo(impl[i], part[i], try { File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toInt() } catch (e: Exception) { 0 })
        }
    }

    /** 0 little, 1 mid, 2 big by max clock; -1 when unknown or all cores are identical. */
    fun clusterOf(i: Int): Int {
        val c = cpus.getOrNull(i) ?: return -1
        val f = freqs
        if (c.khz <= 0 || f.size < 2) return -1
        val r = f.indexOf(c.khz)
        return when { r == 0 -> 0; r == f.size - 1 -> 2; else -> 1 }
    }

    /** Qualcomm Kryo parts are translated back to the Cortex core they are based on. */
    fun coreName(c: CoreInfo, qualcomm: Boolean): String {
        val a = ARM_P.indexOf(c.part)
        return when (c.impl) {
            0x41 -> if (a < 0) "ARM core 0x" + c.part.toString(16) else if (qualcomm) "Kryo (" + ARM_N[a] + ")" else ARM_N[a]
            0x51 -> when (c.part) {
                0x800 -> "Kryo 2XX Gold (Cortex-A73)"; 0x801 -> "Kryo 2XX Silver (Cortex-A53)"
                0x802 -> "Kryo 3XX Gold (Cortex-A75)"; 0x803 -> "Kryo 3XX Silver (Cortex-A55)"
                0x804 -> "Kryo 4XX Gold (Cortex-A76)"; 0x805 -> "Kryo 4XX Silver (Cortex-A55)"
                0x201, 0x205, 0x211 -> "Kryo (custom, first generation)"
                else -> "Qualcomm core 0x" + c.part.toString(16)
            }
            0 -> "unknown core"
            else -> "custom core 0x" + c.impl.toString(16) + "/0x" + c.part.toString(16)
        }
    }

    fun cpuSummary(qualcomm: Boolean): String {
        val g = LinkedHashMap<String, Int>()
        for (c in cpus.sortedBy { it.khz }) {
            val k = coreName(c, qualcomm) + if (c.khz > 0) " @ %.2f GHz".format(c.khz / 1_000_000f) else ""
            g[k] = (g[k] ?: 0) + 1
        }
        return g.entries.joinToString("\n") { it.value.toString() + "× " + it.key }
    }

    private fun readAndroid(): AndroidInfo {
        val rel = Build.VERSION.RELEASE
        val name = when (rel.substringBefore('.').toIntOrNull()) {
            7 -> "Nougat"; 8 -> "Oreo"; 9 -> "Pie"; 13 -> "Tiramisu"; 14 -> "Upside Down Cake"
            15 -> "Vanilla Ice Cream"; 16 -> "Baklava"; else -> ""
        }
        val patch = if (valid(Build.VERSION.SECURITY_PATCH)) " · patch ${Build.VERSION.SECURITY_PATCH}" else ""
        return AndroidInfo("Android $rel" + if (name.isEmpty()) "" else " ($name)", "API ${Build.VERSION.SDK_INT}$patch")
    }
}

/** Downloads a site icon once, keeps it on disk, and holds at most two small bitmaps in memory. */
object Logos {
    private val mem = HashMap<String, ImageBitmap>()
    private val tried = HashMap<String, Long>()

    @Synchronized
    fun get(ctx: Context, domain: String): ImageBitmap? {
        if (domain.isEmpty()) return null
        mem[domain]?.let { return it }
        val f = File(File(ctx.applicationContext.filesDir, "logos").apply { mkdirs() }, "$domain.png")
        if (!f.exists()) {
            val now = System.currentTimeMillis()
            if (now - (tried[domain] ?: 0L) < 3_600_000L) return null   // failed recently: don't hammer the network
            tried[domain] = now
            try {
                val c = URL("https://www.google.com/s2/favicons?domain=$domain&sz=128").openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 6000
                if (c.responseCode == 200) c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                c.disconnect()
            } catch (_: Exception) { f.delete() }
        }
        val bmp = BitmapFactory.decodeFile(f.path) ?: run { f.delete(); return null }
        return bmp.asImageBitmap().also { mem[domain] = it }
    }
}
