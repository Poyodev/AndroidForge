package com.mabobber.tempram

import android.app.ActivityManager
import android.content.*
import android.os.BatteryManager
import android.os.SystemClock
import android.util.Xml
import kotlinx.coroutines.flow.*
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.StringWriter
import kotlin.math.abs

// This file is deliberately free of Compose so the background process (:bg) stays tiny.

data class Config(
    val showTemp: Boolean = true, val showRam: Boolean = true, val showQuote: Boolean = true,
    val showNodes: Boolean = true, val ramUsed: Boolean = true, val fahrenheit: Boolean = false,
    val hotC: Float = 42f, val warmC: Float = 38f, val coldC: Float = 33f, val intervalSec: Int = 2,
    val ovTemp: Boolean = true, val ovRam: Boolean = true, val ovQuote: Boolean = true,
    val ovScale: Float = 1f, val ovAlpha: Float = 0.88f, val always: Boolean = false,
    val ramRed: Int = 80, val ovInterval: Int = 2, val ovTempGraph: Boolean = true,
    val ovRamGraph: Boolean = true, val mainNode: String = "", val histInterval: Int = 60,
    val ovHorizontal: Boolean = false, val nodesAll: Boolean = true,
    val notifTemp: Boolean = true, val notifRam: Boolean = true, val notifNodes: Boolean = true,
    val ovNodes: String = "", val showSoc: Boolean = true, val rankMinutes: Int = 5,
    val ovGraphOnly: Boolean = false, val lineTemp: Int = 0xFFFF9800.toInt(), val lineRam: Int = 0xFF2196F3.toInt(),
    val homeGroup: Int = 0, val ovGroup: Int = 0, val aggMax: Boolean = false,
    val fpsMode: Int = 0, val lineFps: Int = 0xFF9C27B0.toInt(), val notifOnOpen: Boolean = true, val fpsSource: Int = 0, val ignoreBattWarn: Boolean = false,
)

fun Config.pairs(): List<Pair<String, String>> = listOf<Pair<String, Any>>(
    "showTemp" to showTemp, "showRam" to showRam, "showQuote" to showQuote, "showNodes" to showNodes,
    "ramUsed" to ramUsed, "fahrenheit" to fahrenheit, "hotC" to hotC, "warmC" to warmC, "coldC" to coldC,
    "intervalSec" to intervalSec, "ovTemp" to ovTemp, "ovRam" to ovRam, "ovQuote" to ovQuote,
    "ovScale" to ovScale, "ovAlpha" to ovAlpha, "always" to always, "ramRed" to ramRed,
    "ovInterval" to ovInterval, "ovTempGraph" to ovTempGraph, "ovRamGraph" to ovRamGraph,
    "mainNode" to mainNode.replace("\n", ""), "histInterval" to histInterval, "ovHorizontal" to ovHorizontal,
    "nodesAll" to nodesAll, "notifTemp" to notifTemp, "notifRam" to notifRam, "notifNodes" to notifNodes,
    "ovNodes" to ovNodes.replace("\n", ""), "showSoc" to showSoc, "rankMinutes" to rankMinutes,
    "ovGraphOnly" to ovGraphOnly, "lineTemp" to lineTemp, "lineRam" to lineRam,
    "homeGroup" to homeGroup, "ovGroup" to ovGroup, "aggMax" to aggMax,
    "fpsMode" to fpsMode, "lineFps" to lineFps, "notifOnOpen" to notifOnOpen, "fpsSource" to fpsSource, "ignoreBattWarn" to ignoreBattWarn,
).map { it.first to it.second.toString() }

fun Config.set(k: String, v: String): Config = try {
    when (k) {
        "showTemp" -> copy(showTemp = v.toBoolean()); "showRam" -> copy(showRam = v.toBoolean())
        "showQuote" -> copy(showQuote = v.toBoolean()); "showNodes" -> copy(showNodes = v.toBoolean())
        "ramUsed" -> copy(ramUsed = v.toBoolean()); "fahrenheit" -> copy(fahrenheit = v.toBoolean())
        "hotC" -> copy(hotC = v.toFloat()); "warmC" -> copy(warmC = v.toFloat()); "coldC" -> copy(coldC = v.toFloat())
        "intervalSec" -> copy(intervalSec = v.toInt().coerceIn(1, 60))
        "ovTemp" -> copy(ovTemp = v.toBoolean()); "ovRam" -> copy(ovRam = v.toBoolean()); "ovQuote" -> copy(ovQuote = v.toBoolean())
        "ovScale" -> copy(ovScale = v.toFloat().coerceIn(0.6f, 2f)); "ovAlpha" -> copy(ovAlpha = v.toFloat().coerceIn(0.3f, 1f))
        "always" -> copy(always = v.toBoolean()); "ramRed" -> copy(ramRed = v.toInt())
        "ovInterval" -> copy(ovInterval = v.toInt().coerceIn(1, 60))
        "ovTempGraph" -> copy(ovTempGraph = v.toBoolean()); "ovRamGraph" -> copy(ovRamGraph = v.toBoolean())
        "mainNode" -> copy(mainNode = v); "histInterval" -> copy(histInterval = v.toInt().coerceIn(10, 3600))
        "ovHorizontal" -> copy(ovHorizontal = v.toBoolean()); "nodesAll" -> copy(nodesAll = v.toBoolean())
        "notifTemp" -> copy(notifTemp = v.toBoolean()); "notifRam" -> copy(notifRam = v.toBoolean())
        "notifNodes" -> copy(notifNodes = v.toBoolean()); "ovNodes" -> copy(ovNodes = v)
        "showSoc" -> copy(showSoc = v.toBoolean()); "rankMinutes" -> copy(rankMinutes = v.toInt().coerceIn(1, 60))
        "ovGraphOnly" -> copy(ovGraphOnly = v.toBoolean()); "lineTemp" -> copy(lineTemp = v.toInt()); "lineRam" -> copy(lineRam = v.toInt())
        "homeGroup" -> copy(homeGroup = v.toInt().coerceIn(0, 2)); "ovGroup" -> copy(ovGroup = v.toInt().coerceIn(0, 2))
        "aggMax" -> copy(aggMax = v.toBoolean()); "fpsMode" -> copy(fpsMode = v.toInt().coerceIn(0, 2))
        "lineFps" -> copy(lineFps = v.toInt()); "notifOnOpen" -> copy(notifOnOpen = v.toBoolean()); "fpsSource" -> copy(fpsSource = v.toInt().coerceIn(0, 1)); "ignoreBattWarn" -> copy(ignoreBattWarn = v.toBoolean())
        else -> this
    }
} catch (e: Exception) { this }

val ARGB_GREEN = 0xFF4CAF50.toInt()
val ARGB_YELLOW = 0xFFFFC107.toInt()
val ARGB_RED = 0xFFF44336.toInt()

fun Config.t(c: Float) = if (fahrenheit) "%.0f°F".format(c * 9 / 5 + 32) else "%.1f°C".format(c)
fun Config.heat(c: Float) = when { c >= hotC -> Heat.HOT; c <= coldC -> Heat.COLD; else -> Heat.MEDIUM }
fun Config.tempArgb(c: Float) = when { c >= hotC -> ARGB_RED; c >= warmC -> ARGB_YELLOW; else -> ARGB_GREEN }
fun Config.ramArgb(pctUsed: Float) = if (pctUsed >= ramRed) ARGB_RED else ARGB_GREEN

fun gb(x: Long) = "%.2f GB".format(x / 1073741824.0)

const val BATT = "Battery (system)"
fun nodeValue(s: Snap, n: String): Float? = s.nodes.firstOrNull { it.first == n }?.second ?: if (n == BATT) s.battery else null

private val KEYS = arrayOf("soc", "pmu", "pmic", "batt", "gauge", "tsens")
fun isKeyNode(n: String) = KEYS.any { n.contains(it, true) }

enum class Heat(val label: String, val quotes: List<String>) {
    COLD("Cold", listOf("Very sigma 🥶🥶🥶", "Ice cold. Are you even using this phone?")),
    MEDIUM("Medium", listOf("alr don't go far you little shit", "Mid temps. Mid skills. Perfectly balanced.")),
    HOT("Hot", listOf("Bro stop making your fucking phone into a heater god", "Your phone is cooking. Go touch grass while it cools."))
}

/** Fixed-size ring buffer of floats: no boxing, no list shifting. */
class Ring(val cap: Int = 40) {
    private val a = FloatArray(cap)
    private var head = 0
    var size = 0; private set
    fun add(v: Float) { if (size < cap) a[size++] = v else { a[head] = v; head = (head + 1) % cap } }
    operator fun get(i: Int) = a[(head + i) % cap]
}

/** Settings live in one small text file so the UI process and the :bg process can share them. */
object Prefs {
    private var file: File? = null
    private var sig = 0L
    val cfg = MutableStateFlow(Config())
    private fun sigOf(f: File) = f.lastModified() + f.length()

    fun init(c: Context) {
        if (file != null) return
        file = File(c.applicationContext.filesDir, "config.txt"); load()
    }
    private fun load() {
        val f = file ?: return
        if (!f.exists()) return
        sig = sigOf(f)
        var c = Config()
        try { f.forEachLine { l -> val i = l.indexOf('='); if (i > 0) c = c.set(l.substring(0, i), l.substring(i + 1)) } } catch (_: Exception) {}
        cfg.value = c
    }
    /** Cheap cross-process sync: picks up changes the other process wrote. */
    fun reloadIfChanged() { val f = file ?: return; if (f.exists() && sigOf(f) != sig) load() }
    fun update(f: (Config) -> Config) { reloadIfChanged(); cfg.update(f); save() }   // re-read first: the other process may have changed something
    fun live(f: (Config) -> Config) { cfg.update(f) }          // in-memory only (e.g. while dragging)
    fun save() {
        val f = file ?: return
        try { f.writeText(cfg.value.pairs().joinToString("\n") { it.first + "=" + it.second }); sig = sigOf(f) } catch (_: Exception) {}
    }

    fun toXml(): String {
        val s = Xml.newSerializer(); val w = StringWriter()
        s.setOutput(w); s.startDocument("UTF-8", true)
        s.startTag(null, "mabobber"); s.attribute(null, "version", "5.1")
        for ((k, v) in cfg.value.pairs()) { s.startTag(null, "pref"); s.attribute(null, "name", k); s.attribute(null, "value", v); s.endTag(null, "pref") }
        s.endTag(null, "mabobber"); s.endDocument()
        return w.toString()
    }
    fun importXml(ins: InputStream): Boolean = try {
        val p = Xml.newPullParser(); p.setInput(ins, null)
        var c = Config(); var n = 0
        var e = p.eventType
        while (e != XmlPullParser.END_DOCUMENT) {
            if (e == XmlPullParser.START_TAG && p.name == "pref") { c = c.set(p.getAttributeValue(null, "name") ?: "", p.getAttributeValue(null, "value") ?: ""); n++ }
            e = p.next()
        }
        if (n > 0) { cfg.value = c; save() }
        n > 0
    } catch (e: Exception) { false }
}

/** kind: 0 other, 1 CPU little, 2 CPU mid, 3 CPU big, 4 CPU (cluster unknown), 5 GPU */
fun kindOf(n: String): Int {
    val s = n.lowercase()
    if ("gpu" in s) return 5
    if (!("cpu" in s || "cluster" in s || "little" in s || "big" in s)) return 0
    if ("little" in s || "silver" in s || "eff" in s) return 1
    if ("mid" in s || "gold" in s) return 2
    if ("big" in s || "prime" in s || "perf" in s) return 3
    val m = Regex("cpu[-_]?(\\d+)").find(s) ?: return 4
    return when (Soc.clusterOf(m.groupValues[1].toInt())) { 0 -> 1; 1 -> 2; 2 -> 3; else -> 4 }
}

data class Snap(
    val nodes: List<Pair<String, Float>>, val battery: Float?, val temp: Float?,
    val onlyBattery: Boolean, val total: Long, val avail: Long,
    val gAvg: FloatArray, val gMax: FloatArray,      // slots: 0 CPU all, 1 little, 2 mid, 3 big, 4 GPU (NaN = none)
) { val used get() = total - avail }

/** mode 0 raw nodes + battery, 1 CPU / GPU totals, 2 big / mid / little + GPU. Totals are the average (or the hottest sensor). */
fun channels(s: Snap, mode: Int, useMax: Boolean): List<Pair<String, Float>> {
    if (mode == 0) return s.nodes + listOfNotNull(s.battery?.let { BATT to it })
    val a = if (useMax) s.gMax else s.gAvg
    val defs = if (mode == 1) arrayOf("CPU" to 0, "GPU" to 4) else arrayOf("CPU big" to 3, "CPU mid" to 2, "CPU little" to 1, "GPU" to 4)
    return defs.mapNotNull { (n, i) -> if (a[i].isNaN()) null else n to a[i] }
}

class Src(val name: String, val path: String, val tenths: Boolean = false, val kind: Int = 0)

object Monitor {
    val snap = MutableStateFlow<Snap?>(null)
    private var srcs: List<Src>? = null
    private var tick = 0
    private var lastMs = 0L
    private val buf = ByteArray(32)                       // reused for every sensor read: no per-read Strings
    private val mi = ActivityManager.MemoryInfo()
    private val battFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
    private val EXCL = arrayOf("batt", "gauge", "supply")
    private val CPUISH = arrayOf("cpu", "soc", "tsens", "cluster", "big", "little")
    private var am: ActivityManager? = null

    private fun rd(p: String): String? = try { File(p).readText().trim() } catch (e: Exception) { null }

    /** Finds every readable temperature file, the same places AIDA64 / Device Info HW look. */
    private fun discover(): List<Src> {
        val out = mutableListOf<Src>()
        var zones = emptyList<String>()
        for (base in listOf("/sys/class/thermal", "/sys/devices/virtual/thermal")) {
            val l = File(base).list()?.filter { it.startsWith("thermal_zone") }
            if (!l.isNullOrEmpty()) { zones = l.map { "$base/$it" }; break }
        }
        if (zones.isEmpty()) {
            var miss = 0; var i = 0
            while (miss < 8 && i < 100) {
                val d = "/sys/class/thermal/thermal_zone$i"
                if (File("$d/temp").canRead()) { zones = zones + d; miss = 0 } else miss++
                i++
            }
        }
        zones.sortedBy { it.takeLastWhile(Char::isDigit).toIntOrNull() ?: 0 }.forEach { z ->
            out += Src(rd("$z/type") ?: z.substringAfterLast('/'), "$z/temp")
        }
        val hw = File("/sys/class/hwmon").list()?.toList() ?: (0..15).map { "hwmon$it" }
        hw.sorted().forEach { h ->
            val dir = "/sys/class/hwmon/$h"
            val chip = rd("$dir/name") ?: return@forEach
            for (n in 1..12) {
                val p = "$dir/temp${n}_input"
                if (File(p).canRead()) out += Src("$chip " + (rd("$dir/temp${n}_label") ?: "temp$n"), p)
            }
        }
        (File("/sys/class/power_supply").list()?.toList() ?: listOf("battery")).forEach { n ->
            val p = "/sys/class/power_supply/$n/temp"
            if (File(p).canRead()) out += Src("$n (supply)", p, true)
        }
        val seen = HashMap<String, Int>()
        return out.map { s ->
            val c = (seen[s.name] ?: 0) + 1; seen[s.name] = c
            Src(if (c == 1) s.name else "${s.name} $c", s.path, s.tenths, kindOf(s.name))
        }
    }

    private fun parse(n: Int): Float {
        var i = 0; var neg = false
        if (buf[0] == '-'.code.toByte()) { neg = true; i = 1 }
        var v = 0.0; var scale = 0.0; var any = false
        while (i < n) {
            val c = buf[i].toInt()
            if (c in 48..57) {
                any = true
                if (scale == 0.0) v = v * 10 + (c - 48) else { v += (c - 48) * scale; scale /= 10 }
            } else if (c == 46 && scale == 0.0) scale = 0.1 else break
            i++
        }
        return if (!any) Float.NaN else (if (neg) -v else v).toFloat()
    }

    private fun num(path: String): Float = try {
        FileInputStream(path).use { ins -> val n = ins.read(buf); if (n <= 0) Float.NaN else parse(n) }
    } catch (e: Exception) { Float.NaN }

    /** maxAgeMs > 0 lets several loops (UI, overlay, service) share one fresh reading. */
    @Synchronized
    fun sample(ctx: Context, maxAgeMs: Long = 0L) {
        val nowMs = SystemClock.elapsedRealtime()
        if (maxAgeMs > 0 && nowMs - lastMs < maxAgeMs && snap.value != null) return
        lastMs = nowMs
        if (srcs.isNullOrEmpty() && tick++ % 15 == 0) srcs = discover()
        val list = srcs.orEmpty()
        val nodes = ArrayList<Pair<String, Float>>(list.size)
        val sum = FloatArray(5); val cnt = IntArray(5); val mx = FloatArray(5)
        fun acc(i: Int, v: Float) { if (cnt[i]++ == 0 || v > mx[i]) mx[i] = v; sum[i] += v }
        for (s in list) {
            val raw = num(s.path)
            if (raw.isNaN()) continue
            val v = if (s.tenths) raw / 10f else if (abs(raw) >= 1000f) raw / 1000f else raw
            if (v !in -30f..150f || v == 0f) continue
            nodes.add(s.name to v)
            val k = s.kind
            if (k in 1..4) acc(0, v)
            if (k in 1..3) acc(k, v)
            if (k == 5) acc(4, v)
        }
        val gAvg = FloatArray(5) { if (cnt[it] == 0) Float.NaN else sum[it] / cnt[it] }
        val gMax = FloatArray(5) { if (cnt[it] == 0) Float.NaN else mx[it] }
        val bi = ctx.registerReceiver(null, battFilter)
        val bat = bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }?.let { it / 10f }
        val real = nodes.filter { n -> EXCL.none { n.first.contains(it, true) } }
        val cpuish = real.filter { n -> CPUISH.any { n.first.contains(it, true) } }
        val main = Prefs.cfg.value.mainNode
        val temp = nodes.firstOrNull { it.first == main }?.second
            ?: nodes.firstOrNull { it.first.equals("soc_max", true) }?.second
            ?: cpuish.ifEmpty { real }.maxOfOrNull { it.second } ?: bat
        val a = am ?: ctx.applicationContext.getSystemService(Context.ACTIVITY_SERVICE).also { am = it as ActivityManager } as ActivityManager
        a.getMemoryInfo(mi)
        snap.value = Snap(nodes, bat, temp, real.isEmpty(), mi.totalMem, mi.availMem, gAvg, gMax)
    }
}
