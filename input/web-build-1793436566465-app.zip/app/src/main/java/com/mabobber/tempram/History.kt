package com.mabobber.tempram

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

data class AppStat(val pkg: String, val peak: Float, val avg: Float, val minutes: Int)
class DayStat(val key: String, val max: Float, val min: Float, val avg: Float)
class Range(
    val days: List<DayStat?>, val avg: Float, val peak: Float, val peakTs: Long,
    val low: Float, val lowTs: Long, val apps: List<AppStat>,
)
/** A day as primitive arrays (no boxed Floats / per-sample objects). */
class DaySeries(var ts: LongArray, var t: FloatArray, var r: FloatArray, var n: Int = 0)

@Suppress("DEPRECATION")
fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
}

private val labels = HashMap<String, String>()
@Synchronized
fun appLabel(ctx: Context, pkg: String): String = labels.getOrPut(pkg) {
    try {
        val pm = ctx.applicationContext.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }
}

/** Tracks which app is in the foreground using Usage Access (same source as Digital Wellbeing). */
object Fg {
    private var last = ""
    private var since = 0L
    fun current(ctx: Context): String {
        val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        if (since == 0L) since = now - 10 * 60_000L
        try {
            val ev = um.queryEvents(since, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == 1) last = e.packageName } // 1 = app resumed
        } catch (_: Exception) {}
        since = now
        return last
    }
}

object History {
    private fun fmt() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private fun dir(ctx: Context) = File(ctx.filesDir, "history").apply { mkdirs() }
    fun dayKey(ms: Long): String = fmt().format(Date(ms))
    fun dayStart(key: String): Long = fmt().parse(key)!!.time
    fun shift(key: String, delta: Int): String {
        val c = Calendar.getInstance(); c.time = fmt().parse(key)!!
        c.add(Calendar.DAY_OF_YEAR, delta); return fmt().format(c.time)
    }
    fun keys(n: Int): List<String> { val t = dayKey(System.currentTimeMillis()); return (-(n - 1)..0).map { shift(t, it) } }
    fun dayLabel(key: String): String = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(Date(dayStart(key)))
    fun shortDay(key: String): String = SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(dayStart(key)))
    fun weekday(key: String): String = SimpleDateFormat("EEE", Locale.getDefault()).format(Date(dayStart(key)))
    fun clock(ts: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))
    fun stamp(ts: Long): String = SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(ts))

    @Synchronized
    fun append(ctx: Context, s: Long, temp: Float, ram: Float, pkg: String) {
        File(dir(ctx), dayKey(s) + ".csv").appendText(String.format(Locale.US, "%d,%.1f,%.0f,%s\n", s, temp, ram, pkg))
    }

    /** Streams a day file line by line; nothing is kept in memory. */
    private inline fun lines(ctx: Context, key: String, f: (Long, Float, Float, String) -> Unit) {
        val file = File(dir(ctx), "$key.csv")
        if (!file.exists()) return
        try {
            file.bufferedReader().useLines { seq ->
                for (l in seq) {
                    val a = l.indexOf(','); val b = l.indexOf(',', a + 1); val c = l.indexOf(',', b + 1)
                    if (a < 0 || b < 0 || c < 0) continue
                    f(l.substring(0, a).toLong(), l.substring(a + 1, b).toFloat(), l.substring(b + 1, c).toFloat(), l.substring(c + 1))
                }
            }
        } catch (_: Exception) {}
    }

    fun series(ctx: Context, key: String): DaySeries {
        val s = DaySeries(LongArray(512), FloatArray(512), FloatArray(512))
        lines(ctx, key) { ts, t, r, _ ->
            if (s.n == s.ts.size) { val m = s.n * 2; s.ts = s.ts.copyOf(m); s.t = s.t.copyOf(m); s.r = s.r.copyOf(m) }
            s.ts[s.n] = ts; s.t[s.n] = t; s.r[s.n] = r; s.n++
        }
        return s
    }

    fun range(ctx: Context, keys: List<String>, own: String): Range {
        val apps = HashMap<String, FloatArray>()   // [peak, sum, count, seconds]
        val days = ArrayList<DayStat?>(keys.size)
        var sum = 0.0; var cnt = 0; var peak = -1f; var peakTs = 0L; var low = 1000f; var lowTs = 0L
        for (k in keys) {
            var dMax = -1f; var dMin = 1000f; var dSum = 0.0; var dN = 0; var prev = 0L
            lines(ctx, k) { ts, t, _, pkg ->
                dN++; dSum += t
                if (t > dMax) dMax = t
                if (t < dMin) dMin = t
                if (t > peak) { peak = t; peakTs = ts }
                if (t < low) { low = t; lowTs = ts }
                if (pkg.isNotEmpty() && pkg != own) {
                    val a = apps.getOrPut(pkg) { FloatArray(4) }
                    if (t > a[0]) a[0] = t
                    a[1] += t; a[2] += 1f
                    a[3] += if (prev > 0L && ts - prev in 10_000L..600_000L) (ts - prev) / 1000f else 60f
                }
                prev = ts
            }
            days.add(if (dN == 0) null else DayStat(k, dMax, dMin, (dSum / dN).toFloat()))
            sum += dSum; cnt += dN
        }
        val list = apps.map { (p, a) -> AppStat(p, a[0], a[1] / a[2], maxOf(1, (a[3] / 60f).roundToInt())) }
            .sortedWith(compareByDescending<AppStat> { it.peak }.thenByDescending { it.avg })
        return Range(days, if (cnt == 0) 0f else (sum / cnt).toFloat(), peak, peakTs, low, lowTs, list)
    }

    fun weekPeaks(ctx: Context): List<Pair<String, Float?>> {
        val k = keys(7)
        return k.zip(range(ctx, k, "").days.map { it?.max })
    }

    fun prune(ctx: Context) {
        val cutoff = dayKey(System.currentTimeMillis() - 30L * 86_400_000L)
        dir(ctx).listFiles()?.forEach { if (it.nameWithoutExtension < cutoff) it.delete() }
    }

    private val DAY = Regex("\\d{4}-\\d{2}-\\d{2}\\.csv")

    /** One zip with every day file. Format v1: history/yyyy-MM-dd.csv, lines "epochMs,temp,ramPct,package". */
    @Synchronized
    fun exportZip(ctx: Context, out: OutputStream): Int {
        var n = 0
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("tarm-history-v1.txt")); z.write("TARM history export, format 1\n".toByteArray()); z.closeEntry()
            dir(ctx).listFiles()?.filter { DAY.matches(it.name) }?.sortedBy { it.name }?.forEach { f ->
                z.putNextEntry(ZipEntry("history/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry(); n++
            }
        }
        return n
    }

    /** Merges an exported zip into the current history (same timestamp = imported line wins). Returns days imported. */
    @Synchronized
    fun importZip(ctx: Context, inp: InputStream): Int {
        var days = 0
        ZipInputStream(inp).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val name = e.name.substringAfterLast('/')
                if (!e.isDirectory && DAY.matches(name)) {                       // name check also blocks path tricks
                    val bos = ByteArrayOutputStream(); val buf = ByteArray(8192); var total = 0
                    while (true) { val r = z.read(buf); if (r < 0) break; total += r; if (total > 8_000_000) throw IOException("entry too large"); bos.write(buf, 0, r) }
                    mergeDay(ctx, name, bos.toString("UTF-8")); days++
                }
                z.closeEntry(); e = z.nextEntry
            }
        }
        return days
    }

    private fun mergeDay(ctx: Context, name: String, text: String) {
        val f = File(dir(ctx), name)
        val m = TreeMap<Long, String>()
        fun add(l: String) { val i = l.indexOf(','); if (i > 0) l.substring(0, i).toLongOrNull()?.let { m[it] = l } }
        if (f.exists()) f.forEachLine { add(it) }
        text.lineSequence().forEach { add(it) }
        if (m.isNotEmpty()) f.writeText(m.values.joinToString("\n", postfix = "\n"))
    }

    fun clear(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() } }
}
