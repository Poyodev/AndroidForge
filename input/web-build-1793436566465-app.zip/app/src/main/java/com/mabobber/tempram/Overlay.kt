package com.mabobber.tempram

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.Choreographer
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Floating monitor drawn with plain Canvas: no Compose in the :bg process, nothing allocated while drawing
 * except two short strings per update. One render() walks the layout twice (measure, then draw).
 */
class OverlayView(ctx: Context, private val onMove: (Float, Float) -> Unit, private val onClose: () -> Unit) : View(ctx) {
    private val density = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val tHist = Ring()
    private val rHist = Ring()
    private val fHist = Ring()
    private var chans: List<Pair<String, Float>> = emptyList()
    private var lastGroup = 0
    private var fps = 0f
    private var hz = 0f
    private var hzN = 0
    private var hzT0 = 0L
    private var hzRunning = false
    private val rings = HashMap<String, Ring>()
    private var snap: Snap? = null
    private var cfg = Prefs.cfg.value
    private var selKey = "\u0000"
    private var sel: List<String> = emptyList()
    private val closeR = RectF(); private val resizeR = RectF(); private val listR = RectF()
    private var scroll = 0f
    private var qLayout: StaticLayout? = null
    private var qKey = ""
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val handler = Handler(Looper.getMainLooper())

    private fun chanVal(n: String) = chans.firstOrNull { it.first == n }?.second

    /** Current display refresh rate; the vsync source is clamped to it (same idea as the AndroidForge app). */
    private fun dispHz(): Float = try {
        (context.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager)
            .getDisplay(android.view.Display.DEFAULT_DISPLAY).refreshRate
    } catch (e: Exception) { 120f }

    /** Display refresh rate measured from the real vsync ticks (only while the FPS counter is on). */
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (hzT0 == 0L) hzT0 = t
            hzN++
            if (t - hzT0 >= 1_000_000_000L) { hz = hzN * 1e9f / (t - hzT0); hzN = 0; hzT0 = t }
            if (cfg.fpsMode > 0 && isAttachedToWindow) Choreographer.getInstance().postFrameCallback(this)
            else { hzRunning = false; hzT0 = 0L; hzN = 0; hz = 0f }
        }
    }
    private fun ensureHz() { if (cfg.fpsMode > 0 && !hzRunning) { hzRunning = true; Choreographer.getInstance().postFrameCallback(frameCb) } }

    private val tick = object : Runnable {
        override fun run() {
            Prefs.reloadIfChanged(); cfg = Prefs.cfg.value; refreshSel()
            alpha = cfg.ovAlpha
            ensureHz()
            if (pm.isInteractive) {                      // screen off: do nothing
                Monitor.sample(context, 900)
                val s = Monitor.snap.value
                snap = s
                s?.temp?.let { tHist.add(it) }
                s?.let { sn ->
                    rHist.add(sn.used * 100f / sn.total)
                    val ch = channels(sn, cfg.ovGroup, cfg.aggMax); chans = ch
                    if (cfg.ovGroup != 0) { val names = ch.map { it.first }; if (names != sel) { sel = names; rings.keys.retainAll(names.toSet()) } }
                    for (n in sel) chanVal(n)?.let { v -> rings.getOrPut(n) { Ring() }.add(v) }
                    fps = if (cfg.fpsSource == 1) hz.coerceAtMost(dispHz())          // display vsync: no permission needed
                          else if (SystemClock.elapsedRealtime() - Fps.at > 1500) 0f else Fps.fps   // screen capture
                    if (cfg.fpsMode == 1) fHist.add(fps)
                }
                requestLayout(); invalidate()
                handler.postDelayed(this, cfg.ovInterval * 1000L)
            } else handler.postDelayed(this, 5000)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); handler.post(tick) }
    override fun onDetachedFromWindow() { handler.removeCallbacks(tick); Choreographer.getInstance().removeFrameCallback(frameCb); hzRunning = false; super.onDetachedFromWindow() }

    private fun refreshSel() {
        if (cfg.ovGroup != lastGroup) { lastGroup = cfg.ovGroup; selKey = "\u0000"; sel = emptyList(); rings.clear() }
        if (cfg.ovGroup != 0) return          // channel names come from the live snapshot instead
        if (cfg.ovNodes != selKey) {
            selKey = cfg.ovNodes
            sel = if (selKey.isEmpty()) emptyList() else selKey.split("|")
            rings.keys.retainAll(sel.toSet())
        }
    }

    private fun baseW() = if (cfg.ovGraphOnly) 240f else if (cfg.ovHorizontal) 340f else 200f

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        cfg = Prefs.cfg.value; refreshSel()
        val u = density * cfg.ovScale; val w = baseW() * u
        setMeasuredDimension(w.toInt(), render(null, w, u).toInt() + 1)
    }

    override fun onDraw(c: Canvas) { render(c, width.toFloat(), density * cfg.ovScale) }

    // ---------- drawing helpers ----------
    private fun txt(c: Canvas?, s: String, x: Float, y: Float, size: Float, color: Int, a: Paint.Align = Paint.Align.LEFT) {
        if (c == null) return
        p.style = Paint.Style.FILL; p.textSize = size; p.color = color; p.textAlign = a
        c.drawText(s, x, y, p)
    }
    private fun measure(s: String, size: Float): Float { p.textSize = size; p.textAlign = Paint.Align.LEFT; return p.measureText(s) }
    private fun fit(s: String, size: Float, maxW: Float): String {
        if (measure(s, size) <= maxW) return s
        var e = s.length
        while (e > 1 && measure(s.substring(0, e) + "…", size) > maxW) e--
        return s.substring(0, e) + "…"
    }
    private fun graph(c: Canvas?, r: Ring, x: Float, y: Float, w: Float, h: Float, color: Int, lo0: Float?, hi0: Float?, u: Float) {
        if (c == null || r.size < 2) return
        var mn = Float.MAX_VALUE; var mx = -Float.MAX_VALUE
        for (i in 0 until r.size) { val v = r[i]; if (v < mn) mn = v; if (v > mx) mx = v }
        val lo = lo0 ?: (mn - 2f); val hi = hi0 ?: max(mx + 2f, lo + 10f)
        path.rewind()
        for (i in 0 until r.size) {
            val px = x + w * i / (r.size - 1)
            val py = y + h * (1f - ((r[i] - lo) / (hi - lo)).coerceIn(0f, 1f))
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * u; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = color
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
    }
    private fun bar(c: Canvas?, x: Float, y: Float, w: Float, h: Float, f: Float, color: Int) {
        if (c == null) return
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF; rect.set(x, y, x + w, y + h); c.drawRoundRect(rect, h / 2, h / 2, p)
        p.color = color; rect.set(x, y, x + w * f.coerceIn(0f, 1f), y + h); c.drawRoundRect(rect, h / 2, h / 2, p)
    }
    private fun quote(text: String, w: Float, size: Float): StaticLayout {
        val key = text + "|" + w.toInt() + "|" + size.toInt()
        var l = qLayout
        if (key != qKey || l == null) {
            tp.textSize = size; tp.color = 0xCCFFFFFF.toInt()
            l = StaticLayout.Builder.obtain(text, 0, text.length, tp, w.toInt()).build()
            qLayout = l; qKey = key
        }
        return l!!
    }

    // ---------- blocks: each returns the height it used ----------
    private fun tempBlock(c: Canvas?, x: Float, y0: Float, w: Float, u: Float, cf: Config, t: Float?): Float {
        if (!cf.ovTemp) return 0f
        var y = y0
        if (sel.isEmpty()) {
            if (t == null) return 0f
            val col = cf.tempArgb(t)
            if (cf.ovTempGraph) { graph(c, tHist, x, y, w, 44 * u, col, null, null, u); y += 48 * u }
            else { bar(c, x, y, w, 6 * u, t / 80f, col); y += 12 * u }
            return y - y0
        }
        val s = snap
        if (if (cf.ovRam) sel.size <= 2 else sel.size <= 3) {          // RAM on: 1-2 graphs. RAM off: up to 3.
            for (n in sel) {
                val v = chanVal(n) ?: continue
                val col = cf.tempArgb(v)
                txt(c, fit(n, 11 * u, w * 0.6f), x, y + 12 * u, 11 * u, 0xCCFFFFFF.toInt())
                txt(c, cf.t(v), x + w, y + 13 * u, 13 * u, col, Paint.Align.RIGHT)
                y += 18 * u
                if (cf.ovTempGraph) { rings[n]?.let { graph(c, it, x, y, w, 44 * u, col, null, null, u) }; y += 48 * u }
                else { bar(c, x, y, w, 6 * u, v / 80f, col); y += 12 * u }
            }
        } else {                                                      // 3+ nodes with RAM: scrolling numbers only
            val rowH = 20 * u; val total = sel.size * rowH; val vis = min(total, 130 * u)
            scroll = scroll.coerceIn(0f, max(0f, total - vis))
            listR.set(x, y, x + w, y + vis)
            if (c != null) {
                c.save(); c.clipRect(x, y, x + w, y + vis)
                sel.forEachIndexed { i, n ->
                    val v = chanVal(n)
                    val ry = y + i * rowH - scroll
                    if (v != null && ry > y - rowH && ry < y + vis) {
                        txt(c, fit(n, 11 * u, w * 0.6f), x, ry + 14 * u, 11 * u, 0xCCFFFFFF.toInt())
                        txt(c, cf.t(v), x + w, ry + 15 * u, 13 * u, cf.tempArgb(v), Paint.Align.RIGHT)
                    }
                }
                c.restore()
            }
            y += vis
        }
        return y - y0
    }

    private fun ramBlock(c: Canvas?, x: Float, y0: Float, w: Float, u: Float, cf: Config, s: Snap?): Float {
        if (!cf.ovRam || s == null) return 0f
        val pct = s.used * 100f / s.total
        val col = cf.ramArgb(pct)
        txt(c, "RAM ${pct.roundToInt()}% used", x, y0 + 13 * u, 12 * u, col)
        var y = y0 + 18 * u
        if (cf.ovRamGraph) { graph(c, rHist, x, y, w, 44 * u, col, 0f, 100f, u); y += 48 * u }
        else { bar(c, x, y, w, 6 * u, pct / 100f, col); y += 12 * u }
        return y - y0
    }

    /** "Graph only" mode: thermals and RAM share one plot, each line in the colour the user picked. */
    private fun combined(c: Canvas?, x: Float, y0: Float, w: Float, u: Float, cf: Config, t: Float?, s: Snap?): Float {
        var y = y0; val h = 70 * u
        val first = sel.firstOrNull()
        val tr = (if (first == null) tHist else rings[first]) ?: tHist
        val tv = if (first == null) t else chanVal(first)
        if (cf.ovTemp) graph(c, tr, x, y, w, h, cf.lineTemp, null, null, u)
        if (cf.ovRam) graph(c, rHist, x, y, w, h, cf.lineRam, 0f, 100f, u)
        if (cf.fpsMode == 1) graph(c, fHist, x, y, w, h, cf.lineFps, 0f, max(60f, hz), u)
        y += h + 6 * u
        var lx = x
        if (cf.ovTemp && tv != null) { val a = "● " + cf.t(tv); txt(c, a, lx, y + 12 * u, 12 * u, cf.lineTemp); lx += measure(a, 12 * u) + 12 * u }
        if (cf.ovRam && s != null) { val a = "● RAM " + (s.used * 100f / s.total).roundToInt() + "%"; txt(c, a, lx, y + 12 * u, 12 * u, cf.lineRam); lx += measure(a, 12 * u) + 12 * u }
        if (cf.fpsMode == 1) txt(c, "● " + fps.roundToInt() + " fps " + hz.roundToInt() + " Hz", lx, y + 12 * u, 12 * u, cf.lineFps)
        return y + 16 * u - y0
    }

    private fun fpsBlock(c: Canvas?, x: Float, y0: Float, w: Float, u: Float, cf: Config): Float {
        var y = y0 + 4 * u
        val f = fps.roundToInt(); val h = hz.roundToInt()
        if (cf.fpsMode == 2) {                                   // big digits
            txt(c, "$f FPS", x, y + 26 * u, 26 * u, cf.lineFps)
            txt(c, "$h Hz", x + w, y + 24 * u, 16 * u, 0xCCFFFFFF.toInt(), Paint.Align.RIGHT)
            y += 32 * u
        } else {                                                 // own graph
            txt(c, "FPS $f · $h Hz" + if (cf.fpsSource == 1) " (vsync)" else "", x, y + 13 * u, 12 * u, cf.lineFps)
            graph(c, fHist, x, y + 18 * u, w, 44 * u, cf.lineFps, 0f, max(60f, hz), u); y += 66 * u
        }
        if (cf.fpsSource == 0 && !Fps.running) { txt(c, fit("FPS: allow screen capture in Settings", 10 * u, w), x, y + 11 * u, 10 * u, 0x99FFFFFF.toInt()); y += 14 * u }
        return y - y0
    }

    private fun render(c: Canvas?, W: Float, u: Float): Float {
        val cf = cfg; val s = snap; val pad = 12 * u; val iw = W - 2 * pad
        val t = s?.temp
        listR.setEmpty()
        if (c != null) { p.style = Paint.Style.FILL; p.color = 0xF21B2630.toInt(); rect.set(0f, 0f, W, height.toFloat()); c.drawRoundRect(rect, 24 * u, 24 * u, p) }
        var y = pad
        if (cf.ovTemp && t != null && sel.isEmpty() && !cf.ovGraphOnly) txt(c, cf.t(t), pad, y + 24 * u, 26 * u, cf.tempArgb(t))
        txt(c, "✕", W - pad, y + 16 * u, 16 * u, 0xFFFFFFFF.toInt(), Paint.Align.RIGHT)
        closeR.set(W - pad - 34 * u, 0f, W, y + 30 * u)
        y += 32 * u
        if (cf.ovGraphOnly) y += combined(c, pad, y, iw, u, cf, t, s)
        else if (cf.ovHorizontal) {
            val cw = (iw - 12 * u) / 2
            val a = tempBlock(c, pad, y, cw, u, cf, t)
            val b = ramBlock(c, pad + cw + 12 * u, y, cw, u, cf, s)
            y += max(a, b)
        } else { y += tempBlock(c, pad, y, iw, u, cf, t); y += ramBlock(c, pad, y, iw, u, cf, s) }
        if (cf.fpsMode == 2 || (cf.fpsMode == 1 && !cf.ovGraphOnly)) y += fpsBlock(c, pad, y, iw, u, cf)
        if (cf.ovQuote && t != null) {
            y += 4 * u
            val q = quote(cf.heat(t).quotes[0], iw, 11 * u)
            if (c != null) { c.save(); c.translate(pad, y); q.draw(c); c.restore() }
            y += q.height
        }
        txt(c, "⤡ drag to resize", W - pad, y + 12 * u, 10 * u, 0x99FFFFFF.toInt(), Paint.Align.RIGHT)
        resizeR.set(W - pad - 110 * u, y, W, y + 18 * u)
        return y + 18 * u + pad * 0.6f
    }

    // ---------- touch: drag to move, ✕ closes, corner label resizes, node list scrolls ----------
    private var mode = 0
    private var lx = 0f
    private var ly = 0f
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.rawX; ly = e.rawY
                mode = when { closeR.contains(e.x, e.y) -> 1; resizeR.contains(e.x, e.y) -> 2; listR.contains(e.x, e.y) -> 3; else -> 0 }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - lx; val dy = e.rawY - ly; lx = e.rawX; ly = e.rawY
                when (mode) {
                    0 -> onMove(dx, dy)
                    2 -> { Prefs.live { it.copy(ovScale = (it.ovScale + dx / (baseW() * density)).coerceIn(0.6f, 2f)) }; cfg = Prefs.cfg.value; requestLayout() }
                    3 -> { scroll -= dy; invalidate() }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == 1 && closeR.contains(e.x, e.y)) onClose()
                if (mode == 2) Prefs.save()
            }
        }
        return true
    }
}
